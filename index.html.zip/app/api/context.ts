import type { FetchCreateContextFnOptions } from "@trpc/server/adapters/fetch";
import type { User } from "@db/schema";
import { authenticateRequest } from "./kimi/auth";
import { verifyLocalToken } from "./local-auth-router";
import { findLocalUserById } from "./queries/localUsers";

export type UnifiedUser = {
  id: number;
  name: string | null;
  email: string | null;
  avatar?: string | null;
  role: "user" | "admin";
  authType: "oauth" | "local";
};

export type TrpcContext = {
  req: Request;
  resHeaders: Headers;
  user?: User;
  localUser?: UnifiedUser;
};

export async function createContext(
  opts: FetchCreateContextFnOptions,
): Promise<TrpcContext> {
  const ctx: TrpcContext = { req: opts.req, resHeaders: opts.resHeaders };

  // Try OAuth authentication first
  try {
    ctx.user = await authenticateRequest(opts.req.headers);
  } catch {
    // OAuth auth failed, try local auth
  }

  // Try local auth if OAuth didn't work
  if (!ctx.user) {
    try {
      const cookies = opts.req.headers.get("cookie") || "";
      const localTokenMatch = cookies.match(/local_auth_token=([^;]+)/);
      const localToken = localTokenMatch ? localTokenMatch[1] : null;

      if (localToken) {
        const claim = await verifyLocalToken(localToken);
        if (claim) {
          const localUser = await findLocalUserById(claim.localUserId);
          if (localUser) {
            ctx.localUser = {
              id: localUser.id,
              name: localUser.displayName || localUser.username,
              email: localUser.email,
              role: localUser.role as "user" | "admin",
              authType: "local",
            };
          }
        }
      }
    } catch {
      // Local auth failed
    }
  }

  return ctx;
}
