import { useState } from "react";
import { Link } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import {
  ShoppingBag,
  Search,
  User,
  LogOut,
  Menu,
  X,
  Store,
  PlusCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface HeaderProps {
  onLoginClick: () => void;
  onRegisterClick: () => void;
  onSellClick: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

export default function Header({
  onLoginClick,
  onRegisterClick,
  onSellClick,
  searchQuery,
  onSearchChange,
}: HeaderProps) {
  const { user, isAuthenticated, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-[#2c3e50]/95 backdrop-blur-md border-b border-white/10">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 shrink-0">
            <Store className="w-7 h-7 text-[#e74c3c]" />
            <span className="text-xl font-bold text-white">Taifa Market</span>
          </Link>

          {/* Search Bar - Desktop */}
          <div className="hidden md:flex items-center flex-1 max-w-md mx-8">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Search items..."
                className="w-full pl-10 pr-4 py-2 bg-white/10 border border-white/20 rounded-full text-white placeholder-gray-400 focus:outline-none focus:border-[#e74c3c] focus:ring-1 focus:ring-[#e74c3c] transition-all text-sm"
              />
            </div>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-3">
            <Link
              to="/"
              className="text-white/80 hover:text-[#f39c12] transition-colors text-sm font-medium px-3 py-2"
            >
              Home
            </Link>
            <a
              href="#items"
              className="text-white/80 hover:text-[#f39c12] transition-colors text-sm font-medium px-3 py-2 flex items-center gap-1"
            >
              <ShoppingBag className="w-4 h-4" />
              Shop
            </a>

            {isAuthenticated ? (
              <>
                <Button
                  onClick={onSellClick}
                  variant="ghost"
                  size="sm"
                  className="text-[#27ae60] hover:text-[#27ae60] hover:bg-[#27ae60]/10"
                >
                  <PlusCircle className="w-4 h-4 mr-1" />
                  Sell
                </Button>

                <div className="relative">
                  <button
                    onClick={() => setUserMenuOpen(!userMenuOpen)}
                    className="flex items-center gap-2 text-white/80 hover:text-white transition-colors px-3 py-2"
                  >
                    <div className="w-8 h-8 rounded-full bg-[#e74c3c] flex items-center justify-center text-white text-sm font-bold">
                      {user?.name?.charAt(0).toUpperCase() || "U"}
                    </div>
                    <span className="text-sm font-medium max-w-[100px] truncate">
                      {user?.name}
                    </span>
                  </button>

                  {userMenuOpen && (
                    <>
                      <div
                        className="fixed inset-0 z-10"
                        onClick={() => setUserMenuOpen(false)}
                      />
                      <div className="absolute right-0 top-full mt-1 w-48 bg-white rounded-xl shadow-xl border border-gray-100 py-2 z-20">
                        <div className="px-4 py-2 border-b border-gray-100">
                          <p className="text-sm font-medium text-gray-900 truncate">
                            {user?.name}
                          </p>
                          <p className="text-xs text-gray-500">
                            {user?.authType === "local" ? "Local Account" : "Kimi Account"}
                          </p>
                        </div>
                        <button
                          onClick={() => {
                            setUserMenuOpen(false);
                            logout();
                          }}
                          className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 flex items-center gap-2 transition-colors"
                        >
                          <LogOut className="w-4 h-4" />
                          Logout
                        </button>
                      </div>
                    </>
                  )}
                </div>
              </>
            ) : (
              <>
                <Button
                  onClick={onLoginClick}
                  variant="ghost"
                  size="sm"
                  className="text-white hover:text-white hover:bg-white/10"
                >
                  <User className="w-4 h-4 mr-1" />
                  Login
                </Button>
                <Button
                  onClick={onRegisterClick}
                  size="sm"
                  className="bg-[#e74c3c] hover:bg-[#c0392b] text-white rounded-full"
                >
                  Join Now
                </Button>
              </>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-white p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>

        {/* Mobile Search */}
        <div className="md:hidden pb-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search items..."
              className="w-full pl-10 pr-4 py-2 bg-white/10 border border-white/20 rounded-full text-white placeholder-gray-400 focus:outline-none focus:border-[#e74c3c] text-sm"
            />
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#2c3e50] border-t border-white/10 px-4 py-4 space-y-2">
          <Link
            to="/"
            className="block text-white/80 hover:text-[#f39c12] py-2"
            onClick={() => setMobileMenuOpen(false)}
          >
            Home
          </Link>
          <a
            href="#items"
            className="block text-white/80 hover:text-[#f39c12] py-2"
            onClick={() => setMobileMenuOpen(false)}
          >
            Shop
          </a>
          {isAuthenticated ? (
            <>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onSellClick();
                }}
                className="block w-full text-left text-[#27ae60] py-2"
              >
                Sell an Item
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  logout();
                }}
                className="block w-full text-left text-red-400 py-2"
              >
                Logout ({user?.name})
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onLoginClick();
                }}
                className="block w-full text-left text-white/80 py-2"
              >
                Login
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onRegisterClick();
                }}
                className="block w-full text-left text-[#f39c12] py-2"
              >
                Join Now
              </button>
            </>
          )}
        </div>
      )}
    </nav>
  );
}
