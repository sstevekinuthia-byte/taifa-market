import { useState, useEffect, useRef } from "react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send, UserCircle, Loader2 } from "lucide-react";

interface ChatModalProps {
  open: boolean;
  onClose: () => void;
  itemId: number;
  sellerName: string;
}

export default function ChatModal({ open, onClose, itemId, sellerName }: ChatModalProps) {
  const { user } = useAuth();
  const [message, setMessage] = useState("");
  const [buyerName, setBuyerName] = useState(user?.name || "");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { data: messages, isLoading } = trpc.message.listByItem.useQuery(
    { itemId },
    { enabled: open && itemId > 0, refetchInterval: 3000 }
  );

  const utils = trpc.useUtils();
  const sendMessage = trpc.message.create.useMutation({
    onSuccess: () => {
      utils.message.listByItem.invalidate({ itemId });
      setMessage("");
    },
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !buyerName.trim()) return;

    sendMessage.mutate({
      itemId,
      senderName: buyerName.trim(),
      receiverName: sellerName,
      content: message.trim(),
    });
  };

  const sortedMessages = messages ? [...messages].reverse() : [];

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-md p-0 overflow-hidden max-h-[80vh] flex flex-col">
        <DialogHeader className="bg-[#27ae60] text-white p-4 rounded-t-lg">
          <DialogTitle className="flex items-center gap-2 text-white">
            <UserCircle className="w-5 h-5" />
            Chat with {sellerName}
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto p-4 bg-gray-50 min-h-[300px] max-h-[400px] flex flex-col gap-3">
          {!buyerName && (
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mb-2">
              <label className="text-xs text-amber-700 font-medium block mb-1">
                Enter your name to start chatting:
              </label>
              <Input
                value={buyerName}
                onChange={(e) => setBuyerName(e.target.value)}
                placeholder="Your name"
                className="text-sm"
              />
            </div>
          )}

          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-gray-400" />
            </div>
          ) : sortedMessages.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <MessageCircleIcon className="w-12 h-12 mx-auto mb-2 text-gray-300" />
              <p className="text-sm">No messages yet.</p>
              <p className="text-xs">Start the conversation!</p>
            </div>
          ) : (
            sortedMessages.map((msg) => {
              const isMe = msg.senderName === buyerName;
              return (
                <div
                  key={msg.id}
                  className={`max-w-[80%] px-4 py-2.5 rounded-2xl text-sm ${
                    isMe
                      ? "bg-[#27ae60] text-white self-end rounded-br-md"
                      : "bg-white text-gray-800 self-start rounded-bl-md shadow-sm"
                  }`}
                >
                  {!isMe && (
                    <p className="text-xs font-semibold mb-0.5 opacity-70">
                      {msg.senderName}
                    </p>
                  )}
                  <p>{msg.content}</p>
                  <p
                    className={`text-xs mt-1 ${
                      isMe ? "text-white/60" : "text-gray-400"
                    }`}
                  >
                    {new Date(msg.createdAt).toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </p>
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>

        <form
          onSubmit={handleSubmit}
          className="p-3 bg-white border-t flex gap-2"
        >
          {!buyerName && (
            <Input
              value={buyerName}
              onChange={(e) => setBuyerName(e.target.value)}
              placeholder="Your name"
              className="w-24 text-sm"
            />
          )}
          <Input
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Type a message..."
            className="flex-1 text-sm"
            disabled={sendMessage.isPending}
          />
          <Button
            type="submit"
            size="icon"
            className="bg-[#27ae60] hover:bg-[#219a52] rounded-full w-10 h-10 shrink-0"
            disabled={sendMessage.isPending || !message.trim()}
          >
            {sendMessage.isPending ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function MessageCircleIcon({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z" />
    </svg>
  );
}
