import { useState, useRef } from "react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { CloudUpload, Loader2, Camera } from "lucide-react";

interface SellItemModalProps {
  open: boolean;
  onClose: () => void;
}

export default function SellItemModal({ open, onClose }: SellItemModalProps) {
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [location, setLocation] = useState("");
  const [sellerPhone, setSellerPhone] = useState("");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [uploading, setUploading] = useState(false);

  const utils = trpc.useUtils();
  const createItem = trpc.item.create.useMutation({
    onSuccess: () => {
      utils.item.list.invalidate();
      onClose();
      resetForm();
    },
    onError: (err) => {
      setError(err.message || "Failed to create item");
    },
  });

  const resetForm = () => {
    setName("");
    setDescription("");
    setPrice("");
    setLocation("");
    setSellerPhone("");
    setImageFile(null);
    setImagePreview(null);
    setError("");
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      setError("Please select an image file");
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setError("Image must be less than 5MB");
      return;
    }

    setImageFile(file);
    const reader = new FileReader();
    reader.onloadend = () => setImagePreview(reader.result as string);
    reader.readAsDataURL(file);
    setError("");
  };

  const uploadImage = async (): Promise<string | null> => {
    if (!imageFile) return null;

    const formData = new FormData();
    formData.append("file", imageFile);

    const res = await fetch("/api/upload", {
      method: "POST",
      body: formData,
    });

    if (!res.ok) {
      throw new Error("Failed to upload image");
    }

    const data = await res.json();
    return data.url;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!name.trim() || !price.trim() || !location.trim()) {
      setError("Please fill in all required fields");
      return;
    }

    const priceNum = Number(price);
    if (isNaN(priceNum) || priceNum < 0) {
      setError("Please enter a valid price");
      return;
    }

    setUploading(true);

    try {
      let imageUrl = null;
      if (imageFile) {
        imageUrl = await uploadImage();
      }

      await createItem.mutateAsync({
        name: name.trim(),
        description: description.trim() || undefined,
        price: priceNum,
        location: location.trim(),
        image: imageUrl || undefined,
        sellerName: user?.name || "Anonymous",
        sellerPhone: sellerPhone.trim() || undefined,
      });
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : "Failed to upload item";
      setError(errorMessage);
    } finally {
      setUploading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <CloudUpload className="w-5 h-5 text-[#e74c3c]" />
            Sell an Item
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          {error && (
            <div className="bg-red-50 text-red-600 text-sm p-3 rounded-lg">
              {error}
            </div>
          )}

          {/* Image Upload */}
          <div className="space-y-2">
            <Label>Item Photo</Label>
            <div
              onClick={() => fileInputRef.current?.click()}
              className="relative w-full h-44 border-2 border-dashed border-gray-300 rounded-xl flex items-center justify-center cursor-pointer hover:border-[#e74c3c] transition-colors overflow-hidden bg-gray-50"
            >
              {imagePreview ? (
                <img
                  src={imagePreview}
                  alt="Preview"
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="text-center text-gray-400">
                  <Camera className="w-10 h-10 mx-auto mb-2" />
                  <p className="text-sm">Click to upload photo</p>
                </div>
              )}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageSelect}
                className="hidden"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="sell-name">
              Item Name <span className="text-red-500">*</span>
            </Label>
            <Input
              id="sell-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="What are you selling?"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="sell-price">
              Price (KES) <span className="text-red-500">*</span>
            </Label>
            <Input
              id="sell-price"
              type="number"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder="e.g. 2500"
              min="0"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="sell-location">
              Location <span className="text-red-500">*</span>
            </Label>
            <Input
              id="sell-location"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="e.g. Nairobi, CBD"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="sell-phone">Your Phone Number</Label>
            <Input
              id="sell-phone"
              value={sellerPhone}
              onChange={(e) => setSellerPhone(e.target.value)}
              placeholder="e.g. 0712345678"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="sell-desc">Description</Label>
            <Textarea
              id="sell-desc"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe your item..."
              rows={3}
            />
          </div>

          <Button
            type="submit"
            className="w-full bg-[#e74c3c] hover:bg-[#c0392b] text-white"
            disabled={uploading || createItem.isPending}
          >
            {uploading || createItem.isPending ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <CloudUpload className="w-4 h-4 mr-2" />
            )}
            Upload Item
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
