import { eq, desc, sql, like, or } from "drizzle-orm";
import * as schema from "@db/schema";
import type { InsertItem } from "@db/schema";
import { getDb } from "./connection";

export async function findAllItems(search?: string, limit?: number, offset?: number) {
  let query = getDb()
    .select()
    .from(schema.items)
    .orderBy(desc(schema.items.createdAt));

  if (search) {
    const searchPattern = `%${search}%`;
    query = query.where(
      or(
        like(schema.items.name, searchPattern),
        like(schema.items.location, searchPattern),
        like(schema.items.description, searchPattern)
      )
    ) as typeof query;
  }

  if (limit !== undefined && offset !== undefined) {
    query = query.limit(limit).offset(offset) as typeof query;
  }

  return query;
}

export async function countItems(search?: string) {
  let query = getDb()
    .select({ count: sql<number>`count(*)` })
    .from(schema.items);

  if (search) {
    const searchPattern = `%${search}%`;
    query = query.where(
      or(
        like(schema.items.name, searchPattern),
        like(schema.items.location, searchPattern),
        like(schema.items.description, searchPattern)
      )
    ) as typeof query;
  }

  const result = await query;
  return result[0]?.count ?? 0;
}

export async function findItemById(id: number) {
  const rows = await getDb()
    .select()
    .from(schema.items)
    .where(eq(schema.items.id, id))
    .limit(1);
  return rows.at(0);
}

export async function createItem(data: InsertItem) {
  const result = await getDb()
    .insert(schema.items)
    .values(data);
  return result;
}

export async function incrementLikes(id: number) {
  await getDb()
    .update(schema.items)
    .set({ likes: sql`likes + 1` })
    .where(eq(schema.items.id, id));
}
