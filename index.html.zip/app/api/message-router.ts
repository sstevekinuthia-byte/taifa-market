import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import {
  findMessagesByItemId,
  findMessagesBetweenUsers,
  createMessage,
} from "./queries/messages";

export const messageRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        itemId: z.number(),
        senderName: z.string(),
        receiverName: z.string(),
      }),
    )
    .query(async ({ input }) => {
      return findMessagesBetweenUsers(
        input.itemId,
        input.senderName,
        input.receiverName,
      );
    }),

  listByItem: publicQuery
    .input(z.object({ itemId: z.number() }))
    .query(async ({ input }) => {
      return findMessagesByItemId(input.itemId);
    }),

  create: publicQuery
    .input(
      z.object({
        itemId: z.number(),
        senderName: z.string().min(1),
        senderId: z.number().optional(),
        senderType: z.enum(["oauth", "local"]).optional(),
        receiverName: z.string().min(1),
        content: z.string().min(1, "Message content is required"),
      }),
    )
    .mutation(async ({ input }) => {
      await createMessage({
        itemId: input.itemId,
        senderName: input.senderName,
        senderId: input.senderId,
        senderType: input.senderType || "local",
        receiverName: input.receiverName,
        content: input.content,
      });
      return { success: true };
    }),
});
