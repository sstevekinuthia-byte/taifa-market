import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { findCommentsByItemId, createComment } from "./queries/comments";

export const commentRouter = createRouter({
  list: publicQuery
    .input(z.object({ itemId: z.number() }))
    .query(async ({ input }) => {
      return findCommentsByItemId(input.itemId);
    }),

  create: publicQuery
    .input(
      z.object({
        itemId: z.number(),
        authorName: z.string().min(1, "Name is required"),
        text: z.string().min(1, "Comment text is required"),
      }),
    )
    .mutation(async ({ input }) => {
      await createComment({
        itemId: input.itemId,
        authorName: input.authorName,
        text: input.text,
      });
      return { success: true };
    }),
});
