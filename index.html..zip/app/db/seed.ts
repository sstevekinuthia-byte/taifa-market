#!/usr/bin/env tsx
/**
 * Taifa Market - Database Seed Script
 * Run: npx tsx db/seed.ts
 *
 * This script populates the database with sample data.
 * Run it after `npm run db:push` to have demo items to start with.
 */

import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import * as schema from "./schema";
import * as relations from "./relations";

const fullSchema = { ...schema, ...relations };

// Demo items data
const demoItems: schema.InsertItem[] = [
  {
    name: "Samsung Galaxy A54",
    description: "Barely used Samsung Galaxy A54. 128GB storage, 8GB RAM. Comes with original charger and case.",
    price: 35000,
    location: "Nairobi, CBD",
    image: "https://images.unsplash.com/photo-1610945265078-3858a0828671?w=400&q=80",
    sellerName: "John Kamau",
    sellerPhone: "0712345678",
    likes: 5,
  },
  {
    name: "Nike Air Force 1",
    description: "Brand new, size 44. Original Nike Air Force 1 in white. Never worn, still in box.",
    price: 4500,
    location: "Mombasa, Nyali",
    image: "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400&q=80",
    sellerName: "Sarah Ochieng",
    sellerPhone: "0723456789",
    likes: 3,
  },
  {
    name: "HP Laptop 15.6\"",
    description: "HP Pavilion laptop. Intel Core i5, 8GB RAM, 512GB SSD. Good battery life. Minor scratches on lid.",
    price: 28000,
    location: "Kisumu, Milimani",
    image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400&q=80",
    sellerName: "Peter Njoroge",
    sellerPhone: "0734567890",
    likes: 8,
  },
  {
    name: "Wooden Dining Set",
    description: "Beautiful mahogany dining table with 6 chairs. Seats 6 comfortably. Great for family meals.",
    price: 12000,
    location: "Nakuru, Lanet",
    image: "https://images.unsplash.com/photo-1577140917170-285929fb55b7?w=400&q=80",
    sellerName: "Mary Wanjiku",
    sellerPhone: "0745678901",
    likes: 2,
  },
  {
    name: "Sony PlayStation 5",
    description: "PS5 with 2 controllers and 5 games. Games include FIFA 24, GTA V, Spider-Man 2. Like new condition.",
    price: 65000,
    location: "Nairobi, Westlands",
    image: "https://images.unsplash.com/photo-1606813907291-d86efa9b94db?w=400&q=80",
    sellerName: "James Mwangi",
    sellerPhone: "0756789012",
    likes: 12,
  },
  {
    name: "Designer Handbag",
    description: "Authentic designer handbag. Leather, black. Perfect for office or events. Barely used.",
    price: 3500,
    location: "Thika, Town Centre",
    image: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=400&q=80",
    sellerName: "Grace Mutua",
    sellerPhone: "0767890123",
    likes: 1,
  },
];

// Demo comments
const demoComments: Omit<schema.InsertComment, "itemId">[] = [
  { authorName: "Alice", text: "Is the battery still good?" },
  { authorName: "John Kamau", text: "Yes, 95% health!" },
  { authorName: "Mike", text: "What size is this?" },
  { authorName: "David", text: "Can you deliver?" },
  { authorName: "Mary Wanjiku", text: "Yes, extra 500 KES for delivery" },
  { authorName: "Linda", text: "Original or replica?" },
];

async function seed() {
  console.log("Seeding Taifa Market database...\n");

  // Get DATABASE_URL from environment
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    console.error("ERROR: DATABASE_URL environment variable is required!");
    console.error("Run: export DATABASE_URL=mysql://...");
    process.exit(1);
  }

  // Create connection
  const connection = await mysql.createConnection(databaseUrl);
  const db = drizzle(connection, { mode: "planetscale", schema: fullSchema });

  try {
    // 1. Insert items
    console.log("Inserting demo items...");
    for (const item of demoItems) {
      await db.insert(schema.items).values(item);
      process.stdout.write(".");
    }
    console.log(` \u2713 Inserted ${demoItems.length} items`);

    // 2. Get inserted item IDs
    const insertedItems = await db.select({ id: schema.items.id }).from(schema.items);

    // 3. Insert comments (assign to random items)
    console.log("\nInserting demo comments...");
    for (let i = 0; i < demoComments.length; i++) {
      const itemId = insertedItems[i % insertedItems.length]?.id ?? 1;
      await db.insert(schema.comments).values({
        ...demoComments[i],
        itemId,
      });
      process.stdout.write(".");
    }
    console.log(` \u2713 Inserted ${demoComments.length} comments`);

    console.log("\n\nSeed complete! Your marketplace is ready with demo data.");
    console.log(`Items: ${demoItems.length}`);
    console.log(`Comments: ${demoComments.length}`);
    console.log("\nNext: npm run dev");

  } catch (error) {
    console.error("\n\nSeed failed:", error);
    process.exit(1);
  } finally {
    await connection.end();
  }
}

seed();
