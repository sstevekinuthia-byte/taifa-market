import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  bigint,
  int,
} from "drizzle-orm/mysql-core";

// ─── OAuth Users (Kimi Login) ───
export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Local Auth Users (Username/Password) ───
export const localUsers = mysqlTable("local_users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 255 }).notNull().unique(),
  passwordHash: varchar("password_hash", { length: 255 }).notNull(),
  displayName: varchar("display_name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 50 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type LocalUser = typeof localUsers.$inferSelect;
export type InsertLocalUser = typeof localUsers.$inferInsert;

// ─── Marketplace Items ───
export const items = mysqlTable("items", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  price: int("price").notNull(),
  location: varchar("location", { length: 255 }).notNull(),
  description: text("description"),
  imageUrl: text("image_url"),
  sellerName: varchar("seller_name", { length: 255 }).notNull(),
  sellerPhone: varchar("seller_phone", { length: 50 }),
  sellerId: bigint("seller_id", { mode: "number", unsigned: true }),
  sellerType: mysqlEnum("seller_type", ["oauth", "local"]).default("local").notNull(),
  likes: int("likes").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Item = typeof items.$inferSelect;
export type InsertItem = typeof items.$inferInsert;

// ─── Item Comments ───
export const comments = mysqlTable("comments", {
  id: serial("id").primaryKey(),
  itemId: bigint("item_id", { mode: "number", unsigned: true }).notNull(),
  authorName: varchar("author_name", { length: 255 }).notNull(),
  text: text("text").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Comment = typeof comments.$inferSelect;
export type InsertComment = typeof comments.$inferInsert;

// ─── Chat Messages ───
export const messages = mysqlTable("messages", {
  id: serial("id").primaryKey(),
  itemId: bigint("item_id", { mode: "number", unsigned: true }).notNull(),
  senderName: varchar("sender_name", { length: 255 }).notNull(),
  senderId: bigint("sender_id", { mode: "number", unsigned: true }),
  senderType: mysqlEnum("sender_type", ["oauth", "local"]).default("local").notNull(),
  receiverName: varchar("receiver_name", { length: 255 }).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;
