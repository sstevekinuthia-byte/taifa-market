import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import {
  MapPin,
  Heart,
  MessageCircle,
  Phone,
  Send,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface ItemCardProps {
  item: {
    id: number;
    name: string;
    description: string | null;
    price: number;
    location: string;
    image: string | null;
    sellerName: string;
    sellerPhone: string | null;
    likes: number;
    createdAt: Date;
  };
  onChatClick: (itemId: number, sellerName: string) => void;
}

export default function ItemCard({ item, onChatClick }: ItemCardProps) {
  const { user } = useAuth();
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(item.likes);
  const [showComments, setShowComments] = useState(false);
  const [newComment, setNewComment] = useState("");
  const [displayName, setDisplayName] = useState(user?.name || "");

  const utils = trpc.useUtils();
  const { data: comments } = trpc.comment.list.useQuery(
    { itemId: item.id },
    { enabled: showComments }
  );

  const likeMutation = trpc.item.like.useMutation({
    onSuccess: () => {
      utils.item.list.invalidate();
    },
  });

  const commentMutation = trpc.comment.create.useMutation({
    onSuccess: () => {
      utils.comment.list.invalidate({ itemId: item.id });
      setNewComment("");
    },
  });

  const handleLike = () => {
    if (!liked) {
      setLiked(true);
      setLikeCount((prev) => prev + 1);
      likeMutation.mutate({ id: item.id });
    }
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim() || !displayName.trim()) return;
    commentMutation.mutate({
      itemId: item.id,
      authorName: displayName,
      text: newComment.trim(),
    });
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("en-KE", {
      style: "currency",
      currency: "KES",
      minimumFractionDigits: 0,
    }).format(price);
  };

  return (
    <div className="bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl hover:-translate-y-1.5 transition-all duration-300 flex flex-col">
      {/* Image */}
      <div className="relative overflow-hidden h-56 group">
        <img
          src={item.image || "https://via.placeholder.com/400x300?text=No+Image"}
          alt={item.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <button
          onClick={handleLike}
          className="absolute top-3 right-3 w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-md hover:bg-white transition-colors"
        >
          <Heart
            className={`w-5 h-5 transition-colors ${
              liked ? "text-red-500 fill-red-500" : "text-gray-600"
            }`}
          />
        </button>
        <div className="absolute bottom-3 left-3 bg-black/60 backdrop-blur-sm text-white text-xs px-3 py-1 rounded-full">
          {likeCount} likes
        </div>
      </div>

      {/* Body */}
      <div className="p-5 flex flex-col flex-1">
        <h3 className="text-lg font-bold text-[#2c3e50] mb-1 line-clamp-1">
          {item.name}
        </h3>
        <p className="text-xl font-bold text-[#e74c3c] mb-2">
          {formatPrice(item.price)}
        </p>
        <div className="flex items-center gap-1 text-gray-500 text-sm mb-3">
          <MapPin className="w-4 h-4" />
          <span className="line-clamp-1">{item.location}</span>
        </div>

        {/* Seller */}
        <div className="flex items-center gap-2 mb-3 pb-3 border-b border-gray-100">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#e74c3c] to-[#f39c12] flex items-center justify-center text-white text-sm font-bold">
            {item.sellerName.charAt(0).toUpperCase()}
          </div>
          <span className="text-sm text-gray-700 font-medium">
            {item.sellerName}
          </span>
        </div>

        {/* Actions */}
        <div className="flex gap-2 mb-3">
          <Button
            onClick={() => onChatClick(item.id, item.sellerName)}
            variant="outline"
            size="sm"
            className="flex-1 bg-[#27ae60] text-white border-[#27ae60] hover:bg-[#219a52] hover:text-white"
          >
            <MessageCircle className="w-4 h-4 mr-1" />
            Chat
          </Button>
          {item.sellerPhone && (
            <Button
              asChild
              variant="outline"
              size="sm"
              className="flex-1 bg-[#e74c3c] text-white border-[#e74c3c] hover:bg-[#c0392b] hover:text-white"
            >
              <a href={`tel:${item.sellerPhone}`}>
                <Phone className="w-4 h-4 mr-1" />
                Call
              </a>
            </Button>
          )}
        </div>

        {/* Comments */}
        <div className="mt-auto pt-3 border-t border-gray-100">
          <button
            onClick={() => setShowComments(!showComments)}
            className="flex items-center gap-1 text-sm text-gray-500 hover:text-[#2c3e50] transition-colors mb-2"
          >
            {showComments ? (
              <ChevronUp className="w-4 h-4" />
            ) : (
              <ChevronDown className="w-4 h-4" />
            )}
            Comments ({comments?.length ?? 0})
          </button>

          {showComments && (
            <div className="space-y-3">
              <div className="max-h-32 overflow-y-auto space-y-2">
                {comments && comments.length > 0 ? (
                  [...comments].reverse().map((comment) => (
                    <div
                      key={comment.id}
                      className="bg-gray-50 rounded-lg px-3 py-2 text-sm"
                    >
                      <span className="font-semibold text-[#e74c3c]">
                        {comment.authorName}:
                      </span>{" "}
                      <span className="text-gray-700">{comment.text}</span>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-gray-400 italic">
                    No comments yet. Be the first!
                  </p>
                )}
              </div>

              <form onSubmit={handleAddComment} className="flex gap-2">
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="Your name"
                  className="w-20 px-2 py-1.5 text-xs border border-gray-200 rounded-lg focus:outline-none focus:border-[#e74c3c]"
                  required
                />
                <input
                  type="text"
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder="Add a comment..."
                  className="flex-1 px-3 py-1.5 text-xs border border-gray-200 rounded-lg focus:outline-none focus:border-[#e74c3c]"
                  required
                />
                <button
                  type="submit"
                  disabled={commentMutation.isPending}
                  className="px-3 py-1.5 bg-[#2c3e50] text-white rounded-lg hover:bg-[#34495e] transition-colors disabled:opacity-50"
                >
                  <Send className="w-3 h-3" />
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
