import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { LogIn } from "lucide-react";

interface LoginModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSwitchToRegister: () => void;
}

export default function LoginModal({
  open,
  onOpenChange,
  onSwitchToRegister,
}: LoginModalProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/trpc/localAuth.login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          json: { username, password },
        }),
      });

      const data = await res.json();

      if (data.error) {
        setError(data.error.message || "Login failed");
        setLoading(false);
        return;
      }

      // Set cookie
      const token = data.result.data.token;
      document.cookie = `local_auth_token=${token}; Path=/; SameSite=Lax`;

      // Close modal and refresh
      onOpenChange(false);
      setUsername("");
      setPassword("");
      window.location.reload();
    } catch {
      setError("An error occurred. Please try again.");
      setLoading(false);
    }
  };

  const handleOAuthLogin = () => {
    const kimiAuthUrl = import.meta.env.VITE_KIMI_AUTH_URL;
    const appID = import.meta.env.VITE_APP_ID;
    const redirectUri = `${window.location.origin}/api/oauth/callback`;
    const state = btoa(redirectUri);

    const url = new URL(`${kimiAuthUrl}/api/oauth/authorize`);
    url.searchParams.set("client_id", appID);
    url.searchParams.set("redirect_uri", redirectUri);
    url.searchParams.set("response_type", "code");
    url.searchParams.set("scope", "profile");
    url.searchParams.set("state", state);

    window.location.href = url.toString();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-[#2c3e50]">
            <LogIn className="w-5 h-5 text-[#e74c3c]" />
            Login to Taifa Market
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleLogin} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="login-username">Username</Label>
            <Input
              id="login-username"
              type="text"
              placeholder="Enter your username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="login-password">Password</Label>
            <Input
              id="login-password"
              type="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          {error && (
            <p className="text-sm text-red-600 bg-red-50 p-2 rounded">{error}</p>
          )}

          <Button
            type="submit"
            className="w-full bg-[#e74c3c] hover:bg-[#c0392b] text-white"
            disabled={loading}
          >
            {loading ? "Logging in..." : "Login"}
          </Button>
        </form>

        <div className="relative my-4">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-gray-200" />
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="bg-white px-3 text-gray-500">or</span>
          </div>
        </div>

        <Button
          onClick={handleOAuthLogin}
          variant="outline"
          className="w-full border-[#2c3e50] text-[#2c3e50] hover:bg-[#2c3e50] hover:text-white"
        >
          Sign in with Kimi OAuth
        </Button>

        <p className="text-center text-sm text-gray-500 mt-4">
          Don&apos;t have an account?{" "}
          <button
            onClick={() => {
              onOpenChange(false);
              onSwitchToRegister();
            }}
            className="text-[#e74c3c] hover:underline font-medium"
          >
            Register
          </button>
        </p>
      </DialogContent>
    </Dialog>
  );
}
