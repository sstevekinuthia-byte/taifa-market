import { Store, Phone, Mail, Clock } from "lucide-react";

export default function Footer() {
  return (
    <footer id="contact" className="bg-[#2c3e50] text-white">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* About */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Store className="w-6 h-6 text-[#e74c3c]" />
              <h3 className="text-lg font-bold text-[#f39c12]">Taifa Market</h3>
            </div>
            <p className="text-gray-300 text-sm leading-relaxed">
              Your trusted local marketplace. Buy and sell quality items, connect
              with trusted sellers, and shop with confidence.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold text-[#f39c12] mb-4">
              Quick Links
            </h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a
                  href="#home"
                  className="text-gray-300 hover:text-[#e74c3c] transition-colors"
                >
                  Home
                </a>
              </li>
              <li>
                <a
                  href="#items"
                  className="text-gray-300 hover:text-[#e74c3c] transition-colors"
                >
                  Browse Items
                </a>
              </li>
              <li>
                <a
                  href="#contact"
                  className="text-gray-300 hover:text-[#e74c3c] transition-colors"
                >
                  Contact Us
                </a>
              </li>
            </ul>
          </div>

          {/* Customer Care */}
          <div>
            <h3 className="text-lg font-bold text-[#f39c12] mb-4">
              Customer Care
            </h3>
            <div className="bg-white/5 rounded-xl p-4 space-y-3">
              <a
                href="tel:0112698570"
                className="flex items-center gap-3 text-gray-300 hover:text-white transition-colors text-sm"
              >
                <Phone className="w-4 h-4 text-[#f39c12]" />
                0112 698 570
              </a>
              <a
                href="mailto:sngethe332@gmail.com"
                className="flex items-center gap-3 text-gray-300 hover:text-white transition-colors text-sm"
              >
                <Mail className="w-4 h-4 text-[#f39c12]" />
                sngethe332@gmail.com
              </a>
              <div className="flex items-center gap-3 text-gray-300 text-sm">
                <Clock className="w-4 h-4 text-[#f39c12]" />
                Mon - Sat: 8:00 AM - 8:00 PM
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 mt-10 pt-6 text-center text-gray-400 text-sm">
          <p>&copy; 2026 Taifa Market. Twende Shop Tukafanye Shopping!</p>
        </div>
      </div>
    </footer>
  );
}
