import { Store, Phone, Mail, Clock } from "lucide-react";

export default function Footer() {
  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer id="contact" className="bg-[#2c3e50] text-white pt-16 pb-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-10">
          {/* About */}
          <div>
            <h3 className="text-[#f39c12] font-semibold text-lg mb-4 flex items-center gap-2">
              <Store className="w-5 h-5" />
              About Taifa Market
            </h3>
            <p className="text-gray-300 leading-relaxed text-sm">
              Your trusted local marketplace. Buy and sell quality items, connect
              with trusted sellers, and shop with confidence. Twende Shop
              Tukafanye Shopping!
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-[#f39c12] font-semibold text-lg mb-4">
              Quick Links
            </h3>
            <nav className="space-y-3">
              <button
                onClick={() => scrollToSection("home")}
                className="block text-gray-300 hover:text-[#e74c3c] transition-colors text-sm"
              >
                Home
              </button>
              <button
                onClick={() => scrollToSection("items")}
                className="block text-gray-300 hover:text-[#e74c3c] transition-colors text-sm"
              >
                Browse Items
              </button>
              <button
                onClick={() => scrollToSection("items")}
                className="block text-gray-300 hover:text-[#e74c3c] transition-colors text-sm"
              >
                Sell an Item
              </button>
              <button
                onClick={() => scrollToSection("contact")}
                className="block text-gray-300 hover:text-[#e74c3c] transition-colors text-sm"
              >
                Contact Us
              </button>
            </nav>
          </div>

          {/* Customer Care */}
          <div>
            <h3 className="text-[#f39c12] font-semibold text-lg mb-4">
              Customer Care
            </h3>
            <div className="bg-white/5 rounded-xl p-4 space-y-3">
              <a
                href="tel:0112698570"
                className="flex items-center gap-3 text-gray-300 hover:text-[#e74c3c] transition-colors text-sm"
              >
                <Phone className="w-4 h-4 text-[#f39c12]" />
                0112 698 570
              </a>
              <a
                href="mailto:sngethe332@gmail.com"
                className="flex items-center gap-3 text-gray-300 hover:text-[#e74c3c] transition-colors text-sm"
              >
                <Mail className="w-4 h-4 text-[#f39c12]" />
                sngethe332@gmail.com
              </a>
              <div className="flex items-center gap-3 text-gray-300 text-sm">
                <Clock className="w-4 h-4 text-[#f39c12]" />
                Mon - Sat: 8:00 AM - 8:00 PM
              </div>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-white/10 pt-6 text-center">
          <p className="text-gray-400 text-sm">
            &copy; 2026 Taifa Market. Twende Shop Tukafanye Shopping!
          </p>
        </div>
      </div>
    </footer>
  );
}
