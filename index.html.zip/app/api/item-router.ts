import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import {
  findAllItems,
  findItemById,
  createItem,
  incrementLikes,
  countItems,
} from "./queries/items";

export const itemRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        search: z.string().optional(),
        limit: z.number().min(1).max(100).optional(),
        offset: z.number().min(0).optional(),
      }).optional(),
    )
    .query(async ({ input }) => {
      const search = input?.search;
      const limit = input?.limit;
      const offset = input?.offset;
      return findAllItems(search, limit, offset);
    }),

  byId: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return findItemById(input.id);
    }),

  create: publicQuery
    .input(
      z.object({
        name: z.string().min(1, "Item name is required"),
        price: z.number().min(0, "Price must be positive"),
        location: z.string().min(1, "Location is required"),
        description: z.string().optional(),
        imageUrl: z.string().optional(),
        sellerName: z.string().min(1, "Seller name is required"),
        sellerPhone: z.string().optional(),
        sellerId: z.number().optional(),
        sellerType: z.enum(["oauth", "local"]).optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const id = await createItem({
        name: input.name,
        price: input.price,
        location: input.location,
        description: input.description,
        imageUrl: input.imageUrl,
        sellerName: input.sellerName,
        sellerPhone: input.sellerPhone,
        sellerId: input.sellerId,
        sellerType: input.sellerType || "local",
      });
      return { id };
    }),

  like: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await incrementLikes(input.id);
      return { success: true };
    }),

  count: publicQuery.query(async () => {
    return countItems();
  }),
});
