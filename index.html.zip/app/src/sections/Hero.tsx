import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ShoppingBag, UserPlus } from "lucide-react";

const slides = [
  "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=1920&q=80",
  "https://images.unsplash.com/photo-1483985988355-763728e1935b?w=1920&q=80",
  "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1920&q=80",
  "https://images.unsplash.com/photo-1472851294608-062f824d29cc?w=1920&q=80",
];

interface HeroProps {
  onRegisterClick: () => void;
}

export default function Hero({ onRegisterClick }: HeroProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const scrollToItems = () => {
    const el = document.getElementById("items");
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="home" className="relative h-screen flex items-center justify-center overflow-hidden">
      {/* Background Slideshow */}
      <div className="absolute inset-0 z-0">
        {slides.map((slide, index) => (
          <div
            key={index}
            className="absolute inset-0 bg-cover bg-center transition-opacity duration-[2000ms] ease-in-out"
            style={{
              backgroundImage: `url(${slide})`,
              opacity: currentSlide === index ? 1 : 0,
              filter: "brightness(0.35)",
            }}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <h1 className="text-5xl md:text-7xl font-bold text-white mb-4 drop-shadow-2xl animate-[fadeInUp_1s_ease]">
          Taifa Market
        </h1>
        <p className="text-xl md:text-2xl italic text-[#f39c12] mb-8 animate-[fadeInUp_1s_ease_0.3s_both]">
          &ldquo;Twende Shop Tukafanye Shopping&rdquo;
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center animate-[fadeInUp_1s_ease_0.6s_both]">
          <Button
            onClick={scrollToItems}
            size="lg"
            className="bg-[#e74c3c] hover:bg-[#c0392b] text-white px-8 py-6 text-lg rounded-full shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all gap-2"
          >
            <ShoppingBag className="w-5 h-5" />
            Start Shopping
          </Button>
          <Button
            onClick={onRegisterClick}
            size="lg"
            variant="outline"
            className="border-2 border-white text-white hover:bg-white hover:text-[#2c3e50] px-8 py-6 text-lg rounded-full transition-all gap-2"
          >
            <UserPlus className="w-5 h-5" />
            Join Now
          </Button>
        </div>
      </div>

      {/* Slide indicators */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-2 z-10">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
              currentSlide === index
                ? "bg-[#f39c12] w-8"
                : "bg-white/50 hover:bg-white/70"
            }`}
          />
        ))}
      </div>
    </section>
  );
}
