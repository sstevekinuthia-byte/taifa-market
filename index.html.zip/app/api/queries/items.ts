import { eq, desc, sql, like, or } from "drizzle-orm";
import * as schema from "@db/schema";
import type { InsertItem } from "@db/schema";
import { getDb } from "./connection";

export async function findAllItems(search?: string, limit?: number, offset?: number) {
  const db = getDb();
  let query = db.select().from(schema.items).orderBy(desc(schema.items.createdAt));
  
  if (search) {
    const searchTerm = `%${search}%`;
    query = query.where(
      or(
        like(schema.items.name, searchTerm),
        like(schema.items.location, searchTerm),
        like(schema.items.description, searchTerm)
      )
    ) as typeof query;
  }
  
  if (limit) {
    query = query.limit(limit) as typeof query;
  }
  if (offset) {
    query = query.offset(offset) as typeof query;
  }
  
  return query;
}

export async function findItemById(id: number) {
  const rows = await getDb()
    .select()
    .from(schema.items)
    .where(eq(schema.items.id, id))
    .limit(1);
  return rows.at(0);
}

export async function createItem(data: InsertItem) {
  const result = await getDb()
    .insert(schema.items)
    .values(data)
    .$returningId();
  return result[0]?.id;
}

export async function incrementLikes(id: number) {
  await getDb()
    .update(schema.items)
    .set({ likes: sql`${schema.items.likes} + 1` })
    .where(eq(schema.items.id, id));
}

export async function deleteItem(id: number) {
  await getDb()
    .delete(schema.items)
    .where(eq(schema.items.id, id));
}

export async function countItems() {
  const result = await getDb()
    .select({ count: sql<number>`count(*)` })
    .from(schema.items);
  return result[0]?.count ?? 0;
}
