# Taifa Market - Complete Deployment Guide

This guide will teach you how to deploy your Taifa Market application to the internet step by step. We'll cover three deployment options:

1. **Railway (Easiest - Recommended for beginners)**
2. **VPS / Dedicated Server (DigitalOcean, AWS EC2, etc.)**
3. **Render.com**

---

## Table of Contents

- [Step 0: Push to GitHub](#step-0-push-to-github)
- [Option 1: Deploy to Railway](#option-1-deploy-to-railway-easiest)
- [Option 2: Deploy to VPS](#option-2-deploy-to-vps)
- [Option 3: Deploy to Render](#option-3-deploy-to-rendercom)
- [Database Setup Guide](#database-setup-guide)
- [Environment Variables](#environment-variables)
- [Troubleshooting](#troubleshooting)

---

## Step 0: Push to GitHub

Before deploying anywhere, you need to upload your code to GitHub.

### 1. Create a GitHub Repository

1. Go to [github.com](https://github.com) and log in
2. Click the **+** button (top right) -> **New repository**
3. Name it: `taifa-market`
4. Set it to **Public** (or Private if you prefer)
5. **DO NOT** initialize with README (we already have one)
6. Click **Create repository**

### 2. Push Your Code

Open a terminal/command prompt in your project folder and run:

```bash
# Initialize git
git init

# Add all files
git add .

# Commit
git commit -m "Initial Taifa Market commit"

# Add your GitHub repository (replace YOUR_USERNAME with your GitHub username)
git remote add origin https://github.com/YOUR_USERNAME/taifa-market.git

# Push to GitHub
git push -u origin main
```

If you're using `master` branch instead of `main`, use:
```bash
git push -u origin master
```

### 3. Verify

Go to `https://github.com/YOUR_USERNAME/taifa-market` and you should see all your files.

---

## Option 1: Deploy to Railway (Easiest)

[Railway](https://railway.app) is the easiest platform. It handles everything automatically.

### 1. Sign Up

1. Go to [railway.app](https://railway.app)
2. Click **Start a New Project**
3. Sign up with your GitHub account

### 2. Create Project

1. Click **New Project**
2. Click **Deploy from GitHub repo**
3. Select your `taifa-market` repository
4. Railway will auto-detect your app and deploy it

### 3. Add MySQL Database

1. In your Railway project, click **New** -> **Database** -> **Add MySQL**
2. Railway will create a MySQL database for you
3. Go to your database -> **Connect** tab
4. Copy the **Database URL** (looks like `mysql://root:password@host:port/railway`)

### 4. Set Environment Variables

1. Go to your project -> **Variables** tab
2. Add these variables:

```
DATABASE_URL=mysql://root:password@your-mysql-host:port/railway    (from step 3)
APP_ID=your-kimi-app-id
APP_SECRET=your-kimi-app-secret
VITE_APP_ID=your-kimi-app-id
VITE_KIMI_AUTH_URL=https://auth.kimi.com
KIMI_AUTH_URL=https://auth.kimi.com
KIMI_OPEN_URL=https://open.kimi.com
OWNER_UNION_ID=your-union-id
```

3. Railway will automatically redeploy

### 5. Run Database Migrations

1. In Railway, go to your service -> **Deploy** tab
2. Click **Deploy Logs** to see the status
3. To run migrations, use the Railway CLI or SSH:

```bash
# Install Railway CLI
npm i -g @railway/cli

# Login
railway login

# Link to your project
railway link

# Run migrations
railway run npm run db:migrate

# Seed data
railway run npx tsx db/seed.ts
```

### 6. Your App is Live!

1. Go to **Settings** tab in your service
2. Click **Generate Domain** under Public Networking
3. Your app is now live at `https://your-app.up.railway.app`

**Every time you push to GitHub, Railway will automatically redeploy!**

---

## Option 2: Deploy to VPS

For a Virtual Private Server (DigitalOcean, AWS EC2, Linode, Hetzner, etc.)

### 1. Set Up Your Server

Get a server with:
- Ubuntu 22.04 LTS
- At least 1GB RAM
- Domain name (optional but recommended)

### 2. Install Required Software

SSH into your server and run:

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Verify
node --version  # Should show v20.x.x
npm --version

# Install MySQL
sudo apt install -y mysql-server

# Secure MySQL installation
sudo mysql_secure_installation

# Install PM2 (process manager)
sudo npm install -g pm2

# Install Git
sudo apt install -y git
```

### 3. Set Up MySQL

```bash
# Login to MySQL
sudo mysql -u root -p

# In MySQL, create database and user
CREATE DATABASE taifa_market;
CREATE USER 'taifa_user'@'localhost' IDENTIFIED BY 'your_strong_password';
GRANT ALL PRIVILEGES ON taifa_market.* TO 'taifa_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

### 4. Clone Your Repository

```bash
# Create app directory
sudo mkdir -p /var/www
cd /var/www

# Clone your repo (replace with your GitHub URL)
sudo git clone https://github.com/YOUR_USERNAME/taifa-market.git

# Set permissions
sudo chown -R $USER:$USER taifa-market
cd taifa-market

# Install dependencies
npm install

# Build the project
npm run build
```

### 5. Set Up Environment Variables

```bash
# Create .env file
nano .env
```

Paste this (edit values):

```env
DATABASE_URL=mysql://taifa_user:your_strong_password@localhost:3306/taifa_market
APP_ID=your-kimi-app-id
APP_SECRET=your-kimi-app-secret
VITE_APP_ID=your-kimi-app-id
VITE_KIMI_AUTH_URL=https://auth.kimi.com
KIMI_AUTH_URL=https://auth.kimi.com
KIMI_OPEN_URL=https://open.kimi.com
OWNER_UNION_ID=your-union-id
```

Save (Ctrl+O, Enter, Ctrl+X)

### 6. Run Database Migrations & Seed

```bash
# Push database schema
npm run db:push

# Seed with demo data
npx tsx db/seed.ts
```

### 7. Start the Application with PM2

```bash
# Start with PM2
pm2 start dist/boot.js --name taifa-market

# Save PM2 config so it restarts on boot
pm2 save
pm2 startup
```

### 8. Set Up Nginx (Reverse Proxy)

```bash
# Install Nginx
sudo apt install -y nginx

# Create Nginx config
sudo nano /etc/nginx/sites-available/taifa-market
```

Paste this (replace `your-domain.com` with your domain or server IP):

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable the site:
```bash
sudo ln -s /etc/nginx/sites-available/taifa-market /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### 9. Your App is Live!

Visit `http://your-domain.com` or `http://your-server-ip`

### 10. Set Up SSL (HTTPS) - Free with Let's Encrypt

```bash
# Install Certbot
sudo apt install -y certbot python3-certbot-nginx

# Get SSL certificate (replace with your domain)
sudo certbot --nginx -d your-domain.com

# Auto-renew
sudo systemctl enable certbot.timer
```

### 11. Updating Your App

When you make changes and push to GitHub:

```bash
cd /var/www/taifa-market
git pull origin main
npm install
npm run build
npm run db:migrate
pm2 restart taifa-market
```

---

## Option 3: Deploy to Render.com

### 1. Sign Up

1. Go to [render.com](https://render.com)
2. Sign up with GitHub

### 2. Create Web Service

1. Click **New** -> **Web Service**
2. Connect your GitHub repo
3. Set these:
   - **Name**: taifa-market
   - **Runtime**: Node
   - **Build Command**: `npm install && npm run build && npm run db:migrate`
   - **Start Command**: `npm start`

### 3. Add Environment Variables

In the **Environment** tab, add all variables from `.env.example`.

### 4. Set Up MySQL

Render doesn't offer MySQL natively. Use one of these:

**Option A: PlanetScale (Free)**
1. Go to [planetscale.com](https://planetscale.com)
2. Create a database
3. Copy the connection string
4. Set it as `DATABASE_URL` in Render

**Option B: Aiven (Free tier)**
1. Go to [aiven.io](https://aiven.io)
2. Create a free MySQL service
3. Copy the connection details

### 5. Deploy

Click **Create Web Service**. Render will build and deploy automatically.

---

## Environment Variables Reference

| Variable | Required | Description |
|----------|----------|-------------|
| `DATABASE_URL` | Yes | MySQL connection string |
| `APP_ID` | Yes (for OAuth) | Kimi app ID |
| `APP_SECRET` | Yes (for OAuth) | Kimi app secret |
| `VITE_APP_ID` | Yes (for OAuth) | Same as APP_ID |
| `VITE_KIMI_AUTH_URL` | Yes | `https://auth.kimi.com` |
| `KIMI_AUTH_URL` | Yes | `https://auth.kimi.com` |
| `KIMI_OPEN_URL` | Yes | `https://open.kimi.com` |
| `OWNER_UNION_ID` | No | Kimi union ID for admin access |

---

## Troubleshooting

### Database Connection Issues

```bash
# Test MySQL connection
mysql -u root -p -e "SHOW DATABASES;"

# Check if database exists
mysql -u root -p -e "SHOW DATABASES LIKE 'taifa_market';"

# Reset database (WARNING: loses all data!)
npm run db:push
```

### Port Already in Use

```bash
# Find process using port 3000
lsof -ti:3000

# Kill it
kill -9 $(lsof -ti:3000)

# Or restart PM2
pm2 restart taifa-market
```

### Build Errors

```bash
# Clean install
rm -rf node_modules package-lock.json
npm install

# Type check
npm run check

# Build
npm run build
```

### File Upload Not Working

Ensure the `public/uploads` directory exists:
```bash
mkdir -p public/uploads
chmod 755 public/uploads
```

---

## Next Steps

1. **Custom Domain**: Point your domain to your server IP
2. **Backups**: Set up automatic database backups
3. **Monitoring**: Use PM2 monitoring or Railway logs
4. **Updates**: Git push triggers auto-deploy on Railway/Render

## Need Help?

- Check the [backend-building docs](docs/)
- Review [tRPC documentation](https://trpc.io/docs)
- Check [Drizzle ORM docs](https://orm.drizzle.team)
