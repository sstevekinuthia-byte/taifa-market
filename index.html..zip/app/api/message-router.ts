import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import {
  findMessagesByItem,
  findMessagesByItemId,
  createMessage,
} from "./queries/messages";

export const messageRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        itemId: z.number(),
        senderName: z.string(),
        receiverName: z.string(),
      })
    )
    .query(async ({ input }) => {
      return findMessagesByItem(
        input.itemId,
        input.senderName,
        input.receiverName
      );
    }),

  listByItem: publicQuery
    .input(z.object({ itemId: z.number() }))
    .query(async ({ input }) => {
      return findMessagesByItemId(input.itemId);
    }),

  create: publicQuery
    .input(
      z.object({
        itemId: z.number(),
        senderName: z.string().min(1).max(255),
        receiverName: z.string().min(1).max(255),
        content: z.string().min(1).max(5000),
      })
    )
    .mutation(async ({ input }) => {
      await createMessage({
        itemId: input.itemId,
        senderName: input.senderName,
        receiverName: input.receiverName,
        content: input.content,
      });
      return { success: true };
    }),
});
