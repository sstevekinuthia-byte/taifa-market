import { relations } from "drizzle-orm";
import { users, localUsers, items, comments, messages } from "./schema";

export const usersRelations = relations(users, () => ({
  // Add relations if needed
}));

export const localUsersRelations = relations(localUsers, () => ({
  // Add relations if needed
}));

export const itemsRelations = relations(items, ({ many }) => ({
  comments: many(comments),
  messages: many(messages),
}));

export const commentsRelations = relations(comments, ({ one }) => ({
  item: one(items, { fields: [comments.itemId], references: [items.id] }),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  item: one(items, { fields: [messages.itemId], references: [items.id] }),
}));
