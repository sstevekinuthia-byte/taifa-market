import { useState } from "react";
import { trpc } from "@/providers/trpc";
import ItemCard from "./ItemCard";
import { Loader2, PackageOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

interface ItemsGridProps {
  searchQuery: string;
  onChatClick: (itemId: number, sellerName: string) => void;
}

const PAGE_SIZE = 6;

export default function ItemsGrid({ searchQuery, onChatClick }: ItemsGridProps) {
  const [offset, setOffset] = useState(0);

  const { data, isLoading, isFetching } = trpc.item.list.useQuery({
    search: searchQuery || undefined,
    limit: PAGE_SIZE,
    offset,
  });

  const items = data?.items ?? [];
  const total = data?.total ?? 0;
  const hasMore = items.length < total;

  const handleLoadMore = () => {
    setOffset((prev) => prev + PAGE_SIZE);
  };

  return (
    <section id="items" className="py-16 px-4 sm:px-6 lg:px-8 max-w-[1400px] mx-auto">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold text-[#2c3e50] mb-2">
          Latest Uploads
        </h2>
        <p className="text-gray-500">
          Fresh items from sellers near you
        </p>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="bg-white rounded-2xl overflow-hidden shadow-md">
              <Skeleton className="h-56 w-full" />
              <div className="p-5 space-y-3">
                <Skeleton className="h-5 w-3/4" />
                <Skeleton className="h-6 w-1/3" />
                <Skeleton className="h-4 w-1/2" />
                <div className="flex gap-2 pt-2">
                  <Skeleton className="h-9 flex-1" />
                  <Skeleton className="h-9 flex-1" />
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : items.length === 0 ? (
        <div className="text-center py-20">
          <PackageOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-400 mb-2">
            No items found
          </h3>
          <p className="text-gray-400">
            {searchQuery
              ? `No results for "${searchQuery}". Try a different search.`
              : "Be the first to list an item!"}
          </p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {items.map((item) => (
              <ItemCard
                key={item.id}
                item={item}
                onChatClick={onChatClick}
              />
            ))}
          </div>

          {hasMore && (
            <div className="text-center mt-10">
              <Button
                onClick={handleLoadMore}
                disabled={isFetching}
                variant="outline"
                size="lg"
                className="rounded-full px-8"
              >
                {isFetching ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Loading...
                  </>
                ) : (
                  `Load More (${total - items.length} remaining)`
                )}
              </Button>
            </div>
          )}
        </>
      )}
    </section>
  );
}
