import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { MessageCircle, Send, User } from "lucide-react";

interface ChatModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sellerName: string;
  itemId: number;
}

export default function ChatModal({
  open,
  onOpenChange,
  sellerName,
  itemId,
}: ChatModalProps) {
  const { user } = useAuth();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [messageText, setMessageText] = useState("");

  const senderName = user?.name || "Guest";

  const utils = trpc.useUtils();
  const { data: messages, isLoading } = trpc.message.list.useQuery(
    {
      itemId,
      senderName,
      receiverName: sellerName,
    },
    { enabled: open && !!itemId, refetchInterval: 3000 }
  );

  const sendMessage = trpc.message.create.useMutation({
    onSuccess: () => {
      utils.message.list.invalidate({
        itemId,
        senderName,
        receiverName: sellerName,
      });
      setMessageText("");
    },
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = () => {
    if (!messageText.trim()) return;

    sendMessage.mutate({
      itemId,
      senderName,
      senderId: user?.id,
      senderType: user?.authType === "oauth" ? "oauth" : "local",
      receiverName: sellerName,
      content: messageText.trim(),
    });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md p-0 overflow-hidden max-h-[80vh]">
        <DialogHeader className="bg-[#27ae60] text-white p-4 rounded-t-lg">
          <DialogTitle className="flex items-center justify-between text-white">
            <span className="flex items-center gap-2">
              <User className="w-5 h-5" />
              Chat with {sellerName}
            </span>
          </DialogTitle>
        </DialogHeader>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#f0f2f5] min-h-[300px] max-h-[400px]">
          {isLoading ? (
            <div className="text-center text-gray-400 py-8">Loading messages...</div>
          ) : messages && messages.length > 0 ? (
            [...messages].reverse().map((msg) => {
              const isSent = msg.senderName === senderName;
              return (
                <div
                  key={msg.id}
                  className={`flex ${isSent ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[75%] px-3.5 py-2.5 rounded-2xl text-sm ${
                      isSent
                        ? "bg-[#27ae60] text-white rounded-br-md"
                        : "bg-white text-gray-800 rounded-bl-md shadow-sm"
                    }`}
                  >
                    <p>{msg.content}</p>
                    <p
                      className={`text-[10px] mt-1 ${
                        isSent ? "text-white/70" : "text-gray-400"
                      }`}
                    >
                      {new Date(msg.createdAt).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="text-center py-8">
              <MessageCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-400 text-sm">
                Start a conversation with {sellerName}
              </p>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-3 bg-white border-t flex gap-2">
          <Input
            type="text"
            placeholder="Type a message..."
            value={messageText}
            onChange={(e) => setMessageText(e.target.value)}
            onKeyPress={handleKeyPress}
            className="flex-1 rounded-full border-gray-200 focus:border-[#27ae60] focus:ring-[#27ae60]"
          />
          <Button
            onClick={handleSend}
            size="sm"
            className="rounded-full w-10 h-10 p-0 bg-[#27ae60] hover:bg-[#219a52]"
            disabled={!messageText.trim() || sendMessage.isPending}
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
