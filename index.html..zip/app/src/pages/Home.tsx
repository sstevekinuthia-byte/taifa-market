import { useState } from "react";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import ItemsGrid from "@/components/ItemsGrid";
import Footer from "@/components/Footer";
import LoginModal from "@/components/LoginModal";
import RegisterModal from "@/components/RegisterModal";
import SellItemModal from "@/components/SellItemModal";
import ChatModal from "@/components/ChatModal";
import Toast from "@/components/Toast";

export default function Home() {
  const [loginOpen, setLoginOpen] = useState(false);
  const [registerOpen, setRegisterOpen] = useState(false);
  const [sellOpen, setSellOpen] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [chatItemId, setChatItemId] = useState(0);
  const [chatSeller, setChatSeller] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [toast, setToast] = useState({ message: "", visible: false, type: "success" as "success" | "error" });

  const handleChatClick = (itemId: number, sellerName: string) => {
    setChatItemId(itemId);
    setChatSeller(sellerName);
    setChatOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#f5f6fa]">
      <Header
        onLoginClick={() => setLoginOpen(true)}
        onRegisterClick={() => setRegisterOpen(true)}
        onSellClick={() => setSellOpen(true)}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      <div id="home">
        <Hero onRegisterClick={() => setRegisterOpen(true)} />
      </div>

      <ItemsGrid
        searchQuery={searchQuery}
        onChatClick={handleChatClick}
      />

      <Footer />

      <LoginModal
        open={loginOpen}
        onClose={() => setLoginOpen(false)}
        onRegisterClick={() => setRegisterOpen(true)}
      />

      <RegisterModal
        open={registerOpen}
        onClose={() => setRegisterOpen(false)}
        onLoginClick={() => setLoginOpen(true)}
      />

      <SellItemModal
        open={sellOpen}
        onClose={() => setSellOpen(false)}
      />

      <ChatModal
        open={chatOpen}
        onClose={() => setChatOpen(false)}
        itemId={chatItemId}
        sellerName={chatSeller}
      />

      <Toast
        message={toast.message}
        type={toast.type}
        visible={toast.visible}
        onClose={() => setToast((prev) => ({ ...prev, visible: false }))}
      />
    </div>
  );
}
