import { useState, useRef } from "react";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { CloudUpload, Camera, X } from "lucide-react";

interface SellItemModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

export default function SellItemModal({
  open,
  onOpenChange,
  onSuccess,
}: SellItemModalProps) {
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [location, setLocation] = useState("");
  const [description, setDescription] = useState("");
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const utils = trpc.useUtils();
  const createItem = trpc.item.create.useMutation({
    onSuccess: () => {
      utils.item.list.invalidate();
      onSuccess();
      resetForm();
      onOpenChange(false);
    },
  });

  const resetForm = () => {
    setName("");
    setPrice("");
    setLocation("");
    setDescription("");
    setImagePreview(null);
    setImageFile(null);
    setError("");
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      setError("Image must be less than 10MB");
      return;
    }

    setImageFile(file);
    const reader = new FileReader();
    reader.onloadend = () => {
      setImagePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!name.trim() || !price || !location.trim()) {
      setError("Please fill in all required fields");
      return;
    }

    setLoading(true);

    try {
      let imageUrl = "";

      // Upload image if selected
      if (imageFile) {
        const formData = new FormData();
        formData.append("file", imageFile);

        const res = await fetch("/api/upload", {
          method: "POST",
          body: formData,
        });

        const data = await res.json();
        if (data.url) {
          imageUrl = data.url;
        }
      }

      // Create item
      await createItem.mutateAsync({
        name: name.trim(),
        price: parseInt(price),
        location: location.trim(),
        description: description.trim() || undefined,
        imageUrl: imageUrl || undefined,
        sellerName: user?.name || "Anonymous",
        sellerPhone: user?.phone || undefined,
        sellerId: user?.id,
        sellerType: user?.authType === "oauth" ? "oauth" : "local",
      });
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : "Failed to create item";
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-[#2c3e50]">
            <CloudUpload className="w-5 h-5 text-[#e74c3c]" />
            Sell an Item
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Image Upload */}
          <div className="space-y-2">
            <Label>Item Photo</Label>
            <div
              onClick={() => fileInputRef.current?.click()}
              className="relative w-full h-44 border-2 border-dashed border-gray-300 rounded-xl flex flex-col items-center justify-center cursor-pointer hover:border-[#e74c3c] hover:bg-gray-50 transition-all overflow-hidden"
            >
              {imagePreview ? (
                <>
                  <img
                    src={imagePreview}
                    alt="Preview"
                    className="w-full h-full object-cover"
                  />
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setImagePreview(null);
                      setImageFile(null);
                    }}
                    className="absolute top-2 right-2 bg-black/50 text-white p-1 rounded-full hover:bg-black/70"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </>
              ) : (
                <div className="text-center text-gray-400">
                  <Camera className="w-10 h-10 mx-auto mb-2" />
                  <p className="text-sm">Click to upload photo</p>
                </div>
              )}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="hidden"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="item-name">Item Name *</Label>
            <Input
              id="item-name"
              type="text"
              placeholder="What are you selling?"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="item-price">Price (KES) *</Label>
            <Input
              id="item-price"
              type="number"
              placeholder="e.g. 2500"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              required
              min={0}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="item-location">Location *</Label>
            <Input
              id="item-location"
              type="text"
              placeholder="e.g. Nairobi, CBD"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="item-desc">Description</Label>
            <Textarea
              id="item-desc"
              placeholder="Describe your item..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
          </div>

          {error && (
            <p className="text-sm text-red-600 bg-red-50 p-2 rounded">{error}</p>
          )}

          <Button
            type="submit"
            className="w-full bg-[#e74c3c] hover:bg-[#c0392b] text-white"
            disabled={loading || createItem.isPending}
          >
            {loading || createItem.isPending ? "Uploading..." : "Upload Item"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
