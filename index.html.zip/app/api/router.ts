import { authRouter } from "./auth-router";
import { localAuthRouter } from "./local-auth-router";
import { itemRouter } from "./item-router";
import { commentRouter } from "./comment-router";
import { messageRouter } from "./message-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  localAuth: localAuthRouter,
  item: itemRouter,
  comment: commentRouter,
  message: messageRouter,
});

export type AppRouter = typeof appRouter;
