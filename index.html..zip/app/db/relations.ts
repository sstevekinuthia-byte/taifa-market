import { relations } from "drizzle-orm";
import { items, comments, messages } from "./schema";

export const itemsRelations = relations(items, ({ many }) => ({
  comments: many(comments),
  messages: many(messages),
}));

export const commentsRelations = relations(comments, ({ one }) => ({
  item: one(items, {
    fields: [comments.itemId],
    references: [items.id],
  }),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  item: one(items, {
    fields: [messages.itemId],
    references: [items.id],
  }),
}));
