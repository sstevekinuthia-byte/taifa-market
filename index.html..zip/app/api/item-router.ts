import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import {
  findAllItems,
  findItemById,
  createItem,
  incrementLikes,
  countItems,
} from "./queries/items";

export const itemRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        search: z.string().optional(),
        limit: z.number().min(1).max(50).optional(),
        offset: z.number().min(0).optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      const search = input?.search;
      const limit = input?.limit ?? 20;
      const offset = input?.offset ?? 0;

      const [items, total] = await Promise.all([
        findAllItems(search, limit, offset),
        countItems(search),
      ]);

      return { items, total };
    }),

  byId: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const item = await findItemById(input.id);
      return item ?? null;
    }),

  create: publicQuery
    .input(
      z.object({
        name: z.string().min(1).max(255),
        description: z.string().optional(),
        price: z.number().min(0),
        location: z.string().min(1).max(255),
        image: z.string().optional(),
        sellerName: z.string().min(1).max(255),
        sellerPhone: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      await createItem({
        name: input.name,
        description: input.description || null,
        price: input.price,
        location: input.location,
        image: input.image || null,
        sellerName: input.sellerName,
        sellerPhone: input.sellerPhone || null,
      });
      return { success: true };
    }),

  like: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await incrementLikes(input.id);
      return { success: true };
    }),

  count: publicQuery.query(async () => {
    return countItems();
  }),
});
