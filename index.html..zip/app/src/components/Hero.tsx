import { useState, useEffect } from "react";
import { ShoppingBag, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";

const heroImages = [
  "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=1920&q=80",
  "https://images.unsplash.com/photo-1483985988355-763728e1935b?w=1920&q=80",
  "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1920&q=80",
  "https://images.unsplash.com/photo-1472851294608-062f824d29cc?w=1920&q=80",
];

interface HeroProps {
  onRegisterClick: () => void;
}

export default function Hero({ onRegisterClick }: HeroProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroImages.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      {/* Background Slideshow */}
      <div className="absolute inset-0 z-0">
        {heroImages.map((img, i) => (
          <div
            key={i}
            className="absolute inset-0 bg-cover bg-center transition-opacity duration-1000"
            style={{
              backgroundImage: `url(${img})`,
              opacity: i === currentSlide ? 1 : 0,
              filter: "brightness(0.35)",
            }}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <h1 className="text-5xl md:text-7xl font-bold text-white mb-4 animate-fadeInUp drop-shadow-lg">
          Taifa Market
        </h1>
        <p className="text-xl md:text-2xl italic text-[#f39c12] mb-8 animate-fadeInUp animation-delay-300">
          &ldquo;Twende Shop Tukafanye Shopping&rdquo;
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fadeInUp animation-delay-600">
          <Button
            asChild
            size="lg"
            className="bg-[#e74c3c] hover:bg-[#c0392b] text-white rounded-full px-8 py-6 text-lg font-semibold shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all"
          >
            <a href="#items">
              <ShoppingBag className="w-5 h-5 mr-2" />
              Start Shopping
            </a>
          </Button>
          <Button
            onClick={onRegisterClick}
            size="lg"
            variant="outline"
            className="border-2 border-white text-white hover:bg-white hover:text-[#2c3e50] rounded-full px-8 py-6 text-lg font-semibold transition-all"
          >
            <UserPlus className="w-5 h-5 mr-2" />
            Join Now
          </Button>
        </div>
      </div>

      {/* Slide Indicators */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-2 z-10">
        {heroImages.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrentSlide(i)}
            className={`w-3 h-3 rounded-full transition-all ${
              i === currentSlide
                ? "bg-[#e74c3c] w-8"
                : "bg-white/50 hover:bg-white/80"
            }`}
          />
        ))}
      </div>
    </section>
  );
}
