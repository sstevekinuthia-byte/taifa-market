import { useState, useCallback } from "react";
import { useAuth } from "@/hooks/useAuth";
import Header from "@/sections/Header";
import Hero from "@/sections/Hero";
import ItemsGrid from "@/sections/ItemsGrid";
import Footer from "@/sections/Footer";
import LoginModal from "@/components/LoginModal";
import RegisterModal from "@/components/RegisterModal";
import SellItemModal from "@/components/SellItemModal";
import ChatModal from "@/components/ChatModal";
import Toast from "@/components/Toast";

export default function Home() {
  const { user } = useAuth();

  // Modal states
  const [loginOpen, setLoginOpen] = useState(false);
  const [registerOpen, setRegisterOpen] = useState(false);
  const [sellOpen, setSellOpen] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);

  // Chat state
  const [chatSeller, setChatSeller] = useState("");
  const [chatItemId, setChatItemId] = useState(0);

  // Search state
  const [searchQuery, setSearchQuery] = useState("");

  // Toast state
  const [toast, setToast] = useState({
    visible: false,
    message: "",
    type: "success" as "success" | "error",
  });

  const showToast = useCallback((message: string, type: "success" | "error" = "success") => {
    setToast({ visible: true, message, type });
  }, []);

  const handleChatClick = useCallback(
    (sellerName: string, itemId: number) => {
      setChatSeller(sellerName);
      setChatItemId(itemId);
      setChatOpen(true);
    },
    []
  );

  const handleSellClick = useCallback(() => {
    setSellOpen(true);
  }, []);

  const handleRegisterSuccess = useCallback(() => {
    showToast("Account created successfully! Welcome to Taifa Market!");
  }, [showToast]);

  const handleItemUploaded = useCallback(() => {
    showToast("Item listed successfully!");
  }, [showToast]);

  return (
    <div className="min-h-screen bg-[#f5f6fa]">
      <Header
        onLoginClick={() => setLoginOpen(true)}
        onRegisterClick={() => setRegisterOpen(true)}
        onSellClick={handleSellClick}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      <Hero onRegisterClick={() => setRegisterOpen(true)} />

      <ItemsGrid
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onChatClick={handleChatClick}
        currentUserName={user?.name}
      />

      <Footer />

      {/* Modals */}
      <LoginModal
        open={loginOpen}
        onOpenChange={setLoginOpen}
        onSwitchToRegister={() => setRegisterOpen(true)}
      />

      <RegisterModal
        open={registerOpen}
        onOpenChange={setRegisterOpen}
        onSwitchToLogin={() => setLoginOpen(true)}
        onRegisterSuccess={handleRegisterSuccess}
      />

      <SellItemModal
        open={sellOpen}
        onOpenChange={setSellOpen}
        onSuccess={handleItemUploaded}
      />

      <ChatModal
        open={chatOpen}
        onOpenChange={setChatOpen}
        sellerName={chatSeller}
        itemId={chatItemId}
      />

      {/* Toast */}
      <Toast
        message={toast.message}
        type={toast.type}
        visible={toast.visible}
        onClose={() => setToast((prev) => ({ ...prev, visible: false }))}
      />
    </div>
  );
}
