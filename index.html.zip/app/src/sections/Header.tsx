import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Search, Menu, Store, LogOut, PlusCircle, Shield } from "lucide-react";

interface HeaderProps {
  onLoginClick: () => void;
  onRegisterClick: () => void;
  onSellClick: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

export default function Header({
  onLoginClick,
  onRegisterClick,
  onSellClick,
  searchQuery,
  onSearchChange,
}: HeaderProps) {
  const { user, isAuthenticated, isAdmin, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
    setMobileMenuOpen(false);
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-[#2c3e50]/95 backdrop-blur-md border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button
            onClick={() => scrollToSection("home")}
            className="flex items-center gap-2 text-[#e74c3c] font-bold text-xl hover:opacity-90 transition-opacity"
          >
            <Store className="w-6 h-6" />
            <span className="hidden sm:inline">Taifa Market</span>
          </button>

          {/* Desktop Search */}
          <div className="hidden md:flex items-center flex-1 max-w-md mx-8">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                type="text"
                placeholder="Search items..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                className="w-full pl-10 bg-white/10 border-white/20 text-white placeholder:text-gray-400 focus:border-[#e74c3c] focus:ring-[#e74c3c]"
              />
            </div>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-4">
            <button
              onClick={() => scrollToSection("home")}
              className="text-white/80 hover:text-[#f39c12] transition-colors text-sm font-medium"
            >
              Home
            </button>
            <button
              onClick={() => scrollToSection("items")}
              className="text-white/80 hover:text-[#f39c12] transition-colors text-sm font-medium"
            >
              Shop
            </button>
            <button
              onClick={() => scrollToSection("contact")}
              className="text-white/80 hover:text-[#f39c12] transition-colors text-sm font-medium"
            >
              Contact
            </button>

            {isAuthenticated ? (
              <>
                <Button
                  onClick={onSellClick}
                  size="sm"
                  className="bg-[#27ae60] hover:bg-[#219a52] text-white gap-1"
                >
                  <PlusCircle className="w-4 h-4" />
                  Sell
                </Button>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button className="flex items-center gap-2 focus:outline-none">
                      <Avatar className="w-8 h-8 border-2 border-[#f39c12]">
                        <AvatarFallback className="bg-[#e74c3c] text-white text-xs">
                          {user?.name?.charAt(0)?.toUpperCase() || "U"}
                        </AvatarFallback>
                      </Avatar>
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48">
                    <div className="px-3 py-2 text-sm font-medium text-gray-700 border-b">
                      {user?.name || "User"}
                      {isAdmin && (
                        <span className="ml-2 text-[10px] bg-[#e74c3c] text-white px-1.5 py-0.5 rounded-full">
                          ADMIN
                        </span>
                      )}
                    </div>
                    <DropdownMenuItem onClick={onSellClick} className="cursor-pointer gap-2">
                      <PlusCircle className="w-4 h-4" />
                      Sell Item
                    </DropdownMenuItem>
                    {isAdmin && (
                      <DropdownMenuItem className="cursor-pointer gap-2">
                        <Shield className="w-4 h-4" />
                        Admin Panel
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={logout} className="cursor-pointer gap-2 text-red-600">
                      <LogOut className="w-4 h-4" />
                      Logout
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <div className="flex items-center gap-2">
                <Button
                  onClick={onLoginClick}
                  variant="ghost"
                  size="sm"
                  className="text-white hover:text-[#f39c12] hover:bg-white/10"
                >
                  Login
                </Button>
                <Button
                  onClick={onRegisterClick}
                  size="sm"
                  className="bg-[#e74c3c] hover:bg-[#c0392b] text-white"
                >
                  Register
                </Button>
              </div>
            )}
          </div>

          {/* Mobile Menu */}
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild className="md:hidden">
              <button className="text-white p-2">
                <Menu className="w-6 h-6" />
              </button>
            </SheetTrigger>
            <SheetContent side="right" className="bg-[#2c3e50] border-white/10 w-72">
              <div className="flex flex-col gap-6 mt-8">
                {/* Mobile Search */}
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    type="text"
                    placeholder="Search items..."
                    value={searchQuery}
                    onChange={(e) => onSearchChange(e.target.value)}
                    className="w-full pl-10 bg-white/10 border-white/20 text-white placeholder:text-gray-400"
                  />
                </div>

                <nav className="flex flex-col gap-4">
                  <button
                    onClick={() => scrollToSection("home")}
                    className="text-white/80 hover:text-[#f39c12] transition-colors text-left font-medium"
                  >
                    Home
                  </button>
                  <button
                    onClick={() => scrollToSection("items")}
                    className="text-white/80 hover:text-[#f39c12] transition-colors text-left font-medium"
                  >
                    Shop
                  </button>
                  <button
                    onClick={() => scrollToSection("contact")}
                    className="text-white/80 hover:text-[#f39c12] transition-colors text-left font-medium"
                  >
                    Contact
                  </button>
                </nav>

                {isAuthenticated ? (
                  <div className="flex flex-col gap-3 pt-4 border-t border-white/10">
                    <div className="flex items-center gap-3">
                      <Avatar className="w-10 h-10 border-2 border-[#f39c12]">
                        <AvatarFallback className="bg-[#e74c3c] text-white">
                          {user?.name?.charAt(0)?.toUpperCase() || "U"}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-white font-medium">{user?.name}</p>
                        {isAdmin && (
                          <p className="text-[#f39c12] text-xs">Admin</p>
                        )}
                      </div>
                    </div>
                    <Button
                      onClick={() => {
                        onSellClick();
                        setMobileMenuOpen(false);
                      }}
                      className="bg-[#27ae60] hover:bg-[#219a52] text-white gap-2 w-full"
                    >
                      <PlusCircle className="w-4 h-4" />
                      Sell Item
                    </Button>
                    <Button
                      onClick={() => {
                        logout();
                        setMobileMenuOpen(false);
                      }}
                      variant="outline"
                      className="border-red-500 text-red-500 hover:bg-red-500/10 gap-2 w-full"
                    >
                      <LogOut className="w-4 h-4" />
                      Logout
                    </Button>
                  </div>
                ) : (
                  <div className="flex flex-col gap-3 pt-4 border-t border-white/10">
                    <Button
                      onClick={() => {
                        onLoginClick();
                        setMobileMenuOpen(false);
                      }}
                      variant="outline"
                      className="border-white/30 text-white hover:bg-white/10 w-full"
                    >
                      Login
                    </Button>
                    <Button
                      onClick={() => {
                        onRegisterClick();
                        setMobileMenuOpen(false);
                      }}
                      className="bg-[#e74c3c] hover:bg-[#c0392b] text-white w-full"
                    >
                      Register
                    </Button>
                  </div>
                )}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}
