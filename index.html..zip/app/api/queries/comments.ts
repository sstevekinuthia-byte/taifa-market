import { eq, desc } from "drizzle-orm";
import * as schema from "@db/schema";
import type { InsertComment } from "@db/schema";
import { getDb } from "./connection";

export async function findCommentsByItemId(itemId: number) {
  return getDb()
    .select()
    .from(schema.comments)
    .where(eq(schema.comments.itemId, itemId))
    .orderBy(desc(schema.comments.createdAt));
}

export async function createComment(data: InsertComment) {
  const result = await getDb()
    .insert(schema.comments)
    .values(data);
  return result;
}
