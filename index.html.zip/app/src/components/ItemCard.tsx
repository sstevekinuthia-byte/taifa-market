import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Heart,
  MessageCircle,
  Phone,
  MapPin,
  Send,
  ChevronDown,
  ChevronUp,
} from "lucide-react";

interface ItemCardProps {
  id: number;
  name: string;
  price: number;
  location: string;
  description: string | null;
  imageUrl: string | null;
  sellerName: string;
  sellerPhone: string | null;
  likes: number;
  onChatClick: (sellerName: string, itemId: number) => void;
  currentUserName?: string | null;
}

export default function ItemCard({
  id,
  name,
  price,
  location,
  description,
  imageUrl,
  sellerName,
  sellerPhone,
  likes,
  onChatClick,
  currentUserName,
}: ItemCardProps) {
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState("");
  const [likeCount, setLikeCount] = useState(likes);
  const [hasLiked, setHasLiked] = useState(false);

  const utils = trpc.useUtils();
  const { data: comments, isLoading: commentsLoading } =
    trpc.comment.list.useQuery(
      { itemId: id },
      { enabled: showComments }
    );

  const addComment = trpc.comment.create.useMutation({
    onSuccess: () => {
      utils.comment.list.invalidate({ itemId: id });
      setCommentText("");
    },
  });

  const likeItem = trpc.item.like.useMutation({
    onSuccess: () => {
      setLikeCount((prev) => prev + 1);
    },
  });

  const handleLike = () => {
    if (!hasLiked) {
      likeItem.mutate({ id });
      setHasLiked(true);
    }
  };

  const handleAddComment = () => {
    if (!commentText.trim()) return;
    const author = currentUserName || "Guest";
    addComment.mutate({
      itemId: id,
      authorName: author,
      text: commentText.trim(),
    });
  };

  const fallbackImage =
    "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=400&q=80";

  return (
    <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1 group border-0 shadow-md">
      {/* Image */}
      <div className="relative overflow-hidden h-56">
        <img
          src={imageUrl || fallbackImage}
          alt={name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
          onError={(e) => {
            (e.target as HTMLImageElement).src = fallbackImage;
          }}
        />
        <button
          onClick={handleLike}
          className={`absolute top-3 right-3 p-2 rounded-full backdrop-blur-sm transition-all ${
            hasLiked
              ? "bg-[#e74c3c] text-white"
              : "bg-black/30 text-white hover:bg-[#e74c3c]"
          }`}
        >
          <Heart className={`w-4 h-4 ${hasLiked ? "fill-current" : ""}`} />
        </button>
        <div className="absolute bottom-3 left-3 bg-black/50 backdrop-blur-sm text-white text-xs px-2 py-1 rounded-full flex items-center gap-1">
          <Heart className="w-3 h-3" />
          {likeCount}
        </div>
      </div>

      <CardContent className="p-5">
        {/* Title & Price */}
        <div className="flex items-start justify-between gap-2 mb-2">
          <h3 className="font-bold text-[#2c3e50] text-lg leading-tight line-clamp-2">
            {name}
          </h3>
          <span className="text-[#e74c3c] font-bold text-lg whitespace-nowrap">
            KES {price.toLocaleString()}
          </span>
        </div>

        {/* Location */}
        <div className="flex items-center gap-1 text-gray-500 text-sm mb-2">
          <MapPin className="w-3.5 h-3.5" />
          <span>{location}</span>
        </div>

        {/* Description */}
        {description && (
          <p className="text-gray-600 text-sm mb-4 line-clamp-2">{description}</p>
        )}

        {/* Seller */}
        <div className="flex items-center gap-2 mb-4 pb-4 border-b border-gray-100">
          <Avatar className="w-7 h-7">
            <AvatarFallback className="bg-[#2c3e50] text-white text-xs">
              {sellerName.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <span className="text-sm font-medium text-gray-700">{sellerName}</span>
        </div>

        {/* Actions */}
        <div className="flex gap-2 mb-4">
          <Button
            onClick={() => onChatClick(sellerName, id)}
            size="sm"
            className="flex-1 bg-[#27ae60] hover:bg-[#219a52] text-white gap-1.5"
          >
            <MessageCircle className="w-4 h-4" />
            Chat
          </Button>
          {sellerPhone && (
            <a href={`tel:${sellerPhone}`} className="flex-1">
              <Button
                size="sm"
                className="w-full bg-[#e74c3c] hover:bg-[#c0392b] text-white gap-1.5"
              >
                <Phone className="w-4 h-4" />
                Call
              </Button>
            </a>
          )}
        </div>

        {/* Comments Section */}
        <button
          onClick={() => setShowComments(!showComments)}
          className="flex items-center gap-1 text-sm text-gray-500 hover:text-[#e74c3c] transition-colors w-full justify-between"
        >
          <span className="flex items-center gap-1">
            <MessageCircle className="w-4 h-4" />
            Comments ({comments?.length || 0})
          </span>
          {showComments ? (
            <ChevronUp className="w-4 h-4" />
          ) : (
            <ChevronDown className="w-4 h-4" />
          )}
        </button>

        {showComments && (
          <div className="mt-3 pt-3 border-t border-gray-100">
            <div className="max-h-32 overflow-y-auto space-y-2 mb-3">
              {commentsLoading ? (
                <p className="text-sm text-gray-400">Loading comments...</p>
              ) : comments && comments.length > 0 ? (
                comments.map((comment) => (
                  <div
                    key={comment.id}
                    className="bg-gray-50 rounded-lg p-2.5 text-sm"
                  >
                    <span className="font-semibold text-[#e74c3c]">
                      {comment.authorName}:
                    </span>{" "}
                    <span className="text-gray-700">{comment.text}</span>
                  </div>
                ))
              ) : (
                <p className="text-sm text-gray-400 italic">
                  No comments yet. Be the first!
                </p>
              )}
            </div>

            <div className="flex gap-2">
              <Input
                type="text"
                placeholder="Write a comment..."
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleAddComment()}
                className="flex-1 text-sm h-9"
              />
              <Button
                onClick={handleAddComment}
                size="sm"
                className="bg-[#2c3e50] hover:bg-[#1a252f] text-white px-3 h-9"
                disabled={!commentText.trim() || addComment.isPending}
              >
                <Send className="w-3.5 h-3.5" />
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
