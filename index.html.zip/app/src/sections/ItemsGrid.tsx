import { useState, useMemo } from "react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import ItemCard from "@/components/ItemCard";
import { Search, Package, ChevronDown } from "lucide-react";

interface ItemsGridProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onChatClick: (sellerName: string, itemId: number) => void;
  currentUserName?: string | null;
}

export default function ItemsGrid({
  searchQuery,
  onSearchChange,
  onChatClick,
  currentUserName,
}: ItemsGridProps) {
  const [displayLimit, setDisplayLimit] = useState(6);

  const { data: items, isLoading } = trpc.item.list.useQuery({
    search: searchQuery || undefined,
    limit: 100,
  });

  const displayedItems = useMemo(() => {
    if (!items) return [];
    return items.slice(0, displayLimit);
  }, [items, displayLimit]);

  const hasMore = items ? items.length > displayLimit : false;

  return (
    <section id="items" className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="text-center mb-10">
        <h2 className="text-3xl md:text-4xl font-bold text-[#2c3e50] mb-2">
          Latest Uploads
        </h2>
        <p className="text-gray-500">Fresh items from sellers near you</p>
      </div>

      {/* Mobile Search */}
      <div className="md:hidden mb-6 max-w-md mx-auto">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            type="text"
            placeholder="Search items..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full pl-10"
          />
        </div>
      </div>

      {/* Loading Skeleton */}
      {isLoading && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="rounded-xl overflow-hidden border shadow-sm">
              <Skeleton className="h-56 w-full" />
              <div className="p-5 space-y-3">
                <div className="flex justify-between">
                  <Skeleton className="h-5 w-2/3" />
                  <Skeleton className="h-5 w-20" />
                </div>
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-4 w-full" />
                <div className="flex gap-2 pt-2">
                  <Skeleton className="h-9 flex-1" />
                  <Skeleton className="h-9 flex-1" />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Empty State */}
      {!isLoading && (!items || items.length === 0) && (
        <div className="text-center py-16">
          <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-500 mb-2">
            No items found
          </h3>
          <p className="text-gray-400">
            {searchQuery
              ? `No results for "${searchQuery}". Try a different search.`
              : "Be the first to list an item!"}
          </p>
        </div>
      )}

      {/* Items Grid */}
      {!isLoading && items && items.length > 0 && (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {displayedItems.map((item) => (
              <ItemCard
                key={item.id}
                id={item.id}
                name={item.name}
                price={item.price}
                location={item.location}
                description={item.description}
                imageUrl={item.imageUrl}
                sellerName={item.sellerName}
                sellerPhone={item.sellerPhone}
                likes={item.likes}
                onChatClick={onChatClick}
                currentUserName={currentUserName}
              />
            ))}
          </div>

          {/* Load More */}
          {hasMore && (
            <div className="text-center mt-10">
              <Button
                onClick={() => setDisplayLimit((prev) => prev + 6)}
                variant="outline"
                size="lg"
                className="gap-2 border-[#2c3e50] text-[#2c3e50] hover:bg-[#2c3e50] hover:text-white"
              >
                <ChevronDown className="w-4 h-4" />
                Load More
              </Button>
            </div>
          )}
        </>
      )}
    </section>
  );
}
