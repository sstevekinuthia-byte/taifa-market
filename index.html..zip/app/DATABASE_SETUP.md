# Database Setup Guide for Taifa Market

This guide explains how to set up the MySQL database for Taifa Market.

## Option 1: Docker (Recommended for Development)

### Step 1: Install Docker

**Windows/Mac:**
- Download [Docker Desktop](https://www.docker.com/products/docker-desktop/)
- Install and start Docker Desktop

**Linux (Ubuntu):**
```bash
# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Add your user to docker group
sudo usermod -aG docker $USER

# Start Docker
sudo systemctl start docker
sudo systemctl enable docker
```

### Step 2: Start MySQL with Docker Compose

```bash
# In your project folder
docker-compose up -d mysql
```

This will:
- Start a MySQL 8.0 container
- Create database `taifa_market`
- Create user `taifa_user` / password `taifa_pass`
- Expose port 3306

### Step 3: Verify MySQL is Running

```bash
# Check container status
docker ps

# View logs
docker logs taifa-market-mysql

# Connect to MySQL
docker exec -it taifa-market-mysql mysql -u taifa_user -p
# Password: taifa_pass

# In MySQL:
SHOW DATABASES;
USE taifa_market;
SHOW TABLES;
EXIT;
```

### Step 4: Update .env

```bash
# Copy the example
cp .env.example .env

# Edit DATABASE_URL
DATABASE_URL=mysql://taifa_user:taifa_pass@localhost:3306/taifa_market
```

### Step 5: Push Schema & Seed

```bash
# Push database schema (creates all tables)
npm run db:push

# Seed with demo data
npx tsx db/seed.ts
```

### Step 6: Access Database GUI (Optional)

```bash
# Start Adminer (included in docker-compose.yml)
docker-compose up -d adminer

# Visit http://localhost:8080
# Server: mysql
# Username: taifa_user
# Password: taifa_pass
# Database: taifa_market
```

---

## Option 2: Local MySQL Installation

### Step 1: Install MySQL

**Windows:**
1. Download MySQL Installer from [mysql.com](https://dev.mysql.com/downloads/installer/)
2. Run installer, choose "Server Only" or "Full"
3. Set root password during installation
4. Remember the password!

**Mac:**
```bash
# Using Homebrew
brew install mysql
brew services start mysql

# Secure installation
mysql_secure_installation
```

**Linux (Ubuntu):**
```bash
sudo apt update
sudo apt install mysql-server
sudo mysql_secure_installation
```

### Step 2: Create Database and User

```bash
# Login as root
mysql -u root -p

# In MySQL:
CREATE DATABASE taifa_market;
CREATE USER 'taifa_user'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON taifa_market.* TO 'taifa_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

### Step 3: Update .env

```env
DATABASE_URL=mysql://taifa_user:your_password@localhost:3306/taifa_market
```

### Step 4: Push Schema & Seed

```bash
npm run db:push
npx tsx db/seed.ts
```

---

## Option 3: Cloud MySQL (Production)

### PlanetScale (Free tier available)

1. Sign up at [planetscale.com](https://planetscale.com)
2. Create a new database
3. Get your connection string
4. Set it as `DATABASE_URL` in your `.env`

### Aiven (Free tier available)

1. Sign up at [aiven.io](https://aiven.io)
2. Create a MySQL service (free tier available)
3. Copy the connection details
4. Set as `DATABASE_URL`

### AWS RDS

1. Go to AWS Console -> RDS
2. Create a MySQL database
3. Note the endpoint, username, password
4. Set as `DATABASE_URL`

---

## Database Commands Reference

```bash
# Push schema changes (development)
npm run db:push

# Generate migration (production)
npm run db:generate

# Apply migrations (production)
npm run db:migrate

# Seed data
npx tsx db/seed.ts

# View tables (MySQL CLI)
mysql -u taifa_user -p -e "USE taifa_market; SHOW TABLES;"

# View items
mysql -u taifa_user -p -e "USE taifa_market; SELECT * FROM items;"

# Reset everything (DANGER - loses all data!)
drop database taifa_market; create database taifa_market;
```

## Troubleshooting

### "Connection refused"
- MySQL isn't running: `sudo systemctl start mysql` or `brew services start mysql`
- Wrong port: Check MySQL port (default 3306)
- Wrong host: Use `localhost` for local, IP for remote

### "Access denied"
- Wrong password: Double-check credentials
- User doesn't exist: Recreate user with `CREATE USER`
- Permissions: Run `GRANT ALL PRIVILEGES`

### "Database does not exist"
- Create it: `CREATE DATABASE taifa_market;`
- Wrong name: Check your DATABASE_URL
