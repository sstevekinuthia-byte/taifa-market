import { eq, desc, and, or } from "drizzle-orm";
import * as schema from "@db/schema";
import type { InsertMessage } from "@db/schema";
import { getDb } from "./connection";

export async function findMessagesByItemId(itemId: number) {
  return getDb()
    .select()
    .from(schema.messages)
    .where(eq(schema.messages.itemId, itemId))
    .orderBy(desc(schema.messages.createdAt))
    .limit(50);
}

export async function findMessagesBetweenUsers(itemId: number, senderName: string, receiverName: string) {
  return getDb()
    .select()
    .from(schema.messages)
    .where(
      and(
        eq(schema.messages.itemId, itemId),
        or(
          and(
            eq(schema.messages.senderName, senderName),
            eq(schema.messages.receiverName, receiverName)
          ),
          and(
            eq(schema.messages.senderName, receiverName),
            eq(schema.messages.receiverName, senderName)
          )
        )
      )
    )
    .orderBy(desc(schema.messages.createdAt))
    .limit(50);
}

export async function createMessage(data: InsertMessage) {
  await getDb().insert(schema.messages).values(data);
}
