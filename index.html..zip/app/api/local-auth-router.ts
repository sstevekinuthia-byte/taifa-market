import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { createRouter, publicQuery } from "./middleware";
import { findLocalUserByUsername, findLocalUserById, createLocalUser } from "./queries/local-users";
import { SignJWT, jwtVerify } from "jose";

const LOCAL_JWT_SECRET = new TextEncoder().encode(
  process.env.APP_SECRET || "taifa-market-local-secret-key-2026"
);

async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password + "taifa-salt");
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function createLocalToken(userId: number): Promise<string> {
  return new SignJWT({ sub: String(userId), type: "local" })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("30d")
    .sign(LOCAL_JWT_SECRET);
}

export async function verifyLocalToken(token: string) {
  try {
    const { payload } = await jwtVerify(token, LOCAL_JWT_SECRET, {
      clockTolerance: 60,
    });
    const userId = Number(payload.sub);
    if (!userId || isNaN(userId)) return null;
    return findLocalUserById(userId);
  } catch {
    return null;
  }
}

export const localAuthRouter = createRouter({
  register: publicQuery
    .input(
      z.object({
        username: z.string().min(3).max(50),
        displayName: z.string().min(1).max(100),
        password: z.string().min(6).max(100),
        mobile: z.string().optional(),
        email: z.string().email().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const existing = await findLocalUserByUsername(input.username);
      if (existing) {
        throw new TRPCError({
          code: "CONFLICT",
          message: "Username already taken",
        });
      }

      const passwordHash = await hashPassword(input.password);
      await createLocalUser({
        username: input.username,
        displayName: input.displayName,
        passwordHash,
        mobile: input.mobile || null,
        email: input.email || null,
      });

      const user = await findLocalUserByUsername(input.username);
      if (!user) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to create user",
        });
      }

      const token = await createLocalToken(user.id);
      return {
        token,
        user: {
          id: user.id,
          name: user.displayName,
          username: user.username,
          role: user.role,
        },
      };
    }),

  login: publicQuery
    .input(
      z.object({
        username: z.string(),
        password: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const user = await findLocalUserByUsername(input.username);
      if (!user) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Invalid username or password",
        });
      }

      const passwordHash = await hashPassword(input.password);
      if (user.passwordHash !== passwordHash) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Invalid username or password",
        });
      }

      const token = await createLocalToken(user.id);
      return {
        token,
        user: {
          id: user.id,
          name: user.displayName,
          username: user.username,
          role: user.role,
        },
      };
    }),

  me: publicQuery.query(async ({ ctx }) => {
    const authHeader = ctx.req.headers.get("x-local-auth-token");
    if (!authHeader) return null;

    const user = await verifyLocalToken(authHeader);
    if (!user) return null;

    return {
      id: user.id,
      name: user.displayName,
      username: user.username,
      mobile: user.mobile,
      email: user.email,
      role: user.role,
      createdAt: user.createdAt,
    };
  }),

  logout: publicQuery.mutation(() => {
    return { success: true };
  }),
});
