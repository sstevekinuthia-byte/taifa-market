import type { FetchCreateContextFnOptions } from "@trpc/server/adapters/fetch";
import type { User, LocalUser } from "@db/schema";
import { authenticateRequest } from "./kimi/auth";
import { verifyLocalToken } from "./local-auth-router";

export type UnifiedUser = {
  id: number;
  name: string;
  email?: string | null;
  avatar?: string | null;
  role: string;
  authType: "oauth" | "local";
};

export type TrpcContext = {
  req: Request;
  resHeaders: Headers;
  user?: User;
  localUser?: LocalUser;
  unifiedUser?: UnifiedUser;
};

export async function createContext(
  opts: FetchCreateContextFnOptions,
): Promise<TrpcContext> {
  const ctx: TrpcContext = { req: opts.req, resHeaders: opts.resHeaders };

  // Try OAuth authentication
  try {
    ctx.user = await authenticateRequest(opts.req.headers);
    if (ctx.user) {
      ctx.unifiedUser = {
        id: ctx.user.id,
        name: ctx.user.name || "User",
        email: ctx.user.email,
        avatar: ctx.user.avatar,
        role: ctx.user.role,
        authType: "oauth",
      };
    }
  } catch {
    // OAuth auth is optional
  }

  // Try local auth if no OAuth user
  if (!ctx.unifiedUser) {
    try {
      const localToken = opts.req.headers.get("x-local-auth-token");
      if (localToken) {
        const localUserResult = await verifyLocalToken(localToken);
        if (localUserResult) {
          ctx.localUser = localUserResult;
          ctx.unifiedUser = {
            id: ctx.localUser.id,
            name: ctx.localUser.displayName || ctx.localUser.username,
            email: ctx.localUser.email,
            avatar: null,
            role: ctx.localUser.role,
            authType: "local",
          };
        }
      }
    } catch {
      // Local auth is optional
    }
  }

  return ctx;
}
