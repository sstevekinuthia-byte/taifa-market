# Taifa Market

**Twende Shop Tukafanye Shopping** - A fullstack local marketplace web application built with React, tRPC, Drizzle ORM, and MySQL.

![Taifa Market](https://img.shields.io/badge/Taifa-Market-red?style=for-the-badge)
![React](https://img.shields.io/badge/React-19-blue?style=for-the-badge&logo=react)
![TypeScript](https://img.shields.io/badge/TypeScript-5.9-blue?style=for-the-badge&logo=typescript)
![tRPC](https://img.shields.io/badge/tRPC-11-blue?style=for-the-badge)
![MySQL](https://img.shields.io/badge/MySQL-8.0-orange?style=for-the-badge&logo=mysql)

## Features

- **Hero Section** - Full-viewport animated slideshow with 4 background images
- **Items Catalog** - Responsive grid with search, pagination, skeleton loading
- **Item Cards** - Image hover zoom, like button, seller info, collapsible comments
- **Chat System** - Buyer-seller messaging with auto-refresh
- **Sell Item** - Image upload with preview, name, price, location, description
- **Dual Authentication** - Local username/password + Kimi OAuth 2.0
- **Customer Care** - Phone, email, business hours in footer

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 19 + TypeScript + Tailwind CSS + shadcn/ui |
| Backend | Hono + tRPC 11 + Drizzle ORM + MySQL |
| Auth | Dual: Local (SHA-256 + JWT) + Kimi OAuth 2.0 |
| File Uploads | Hono multipart handling with local storage |

## Database Schema

| Table | Purpose |
|-------|---------|
| `users` | OAuth users (Kimi login) with role support |
| `local_users` | Local auth users with password hashes |
| `items` | Marketplace listings with seller info, price, location |
| `comments` | Item comments with author name |
| `messages` | Chat messages between buyers and sellers |

## Quick Start (Local Development)

### Prerequisites
- Node.js 20+
- MySQL 8.0+ (or use Docker)

### 1. Clone and Install

```bash
git clone <your-repo-url>
cd taifa-market
npm install
```

### 2. Set Up Environment Variables

```bash
cp .env.example .env
# Edit .env with your credentials
```

### 3. Set Up Database

**Option A: Using Docker (Recommended)**

```bash
docker-compose up -d mysql
npm run db:push
npm run db:seed
```

**Option B: Using Existing MySQL**

```bash
# Update DATABASE_URL in .env
npm run db:push
npm run db:seed
```

### 4. Run Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

### 5. Build for Production

```bash
npm run build
npm start
```

## API Endpoints (tRPC Routers)

| Router | Endpoints | Description |
|--------|-----------|-------------|
| `auth` | `me`, `logout` | OAuth authentication |
| `localAuth` | `register`, `login`, `me`, `logout` | Local authentication |
| `item` | `list`, `byId`, `create`, `like`, `count` | Marketplace items |
| `comment` | `list`, `create` | Item comments |
| `message` | `list`, `listByItem`, `create` | Chat messages |

Plus REST endpoints:
- `POST /api/upload` - File upload
- `POST /api/local-logout` - Local auth logout
- `GET /api/oauth/callback` - OAuth callback

## Project Structure

```
.
├── api/                    # Backend API
│   ├── boot.ts            # Hono server entry
│   ├── router.ts          # tRPC router registry
│   ├── context.ts         # tRPC context (dual auth)
│   ├── middleware.ts      # Auth middleware
│   ├── auth-router.ts     # OAuth auth router
│   ├── local-auth-router.ts  # Local auth router
│   ├── item-router.ts     # Items router
│   ├── comment-router.ts  # Comments router
│   ├── message-router.ts  # Messages router
│   ├── queries/           # Database query functions
│   └── kim/              # Kimi OAuth SDK
├── contracts/             # Shared types/constants
├── db/                    # Database schema & migrations
│   ├── schema.ts          # All table definitions
│   ├── relations.ts       # Drizzle relations
│   └── seed.ts            # Seed data script
├── src/
│   ├── components/        # React components
│   │   ├── Header.tsx
│   │   ├── Hero.tsx
│   │   ├── ItemCard.tsx
│   │   ├── ItemsGrid.tsx
│   │   ├── Footer.tsx
│   │   ├── LoginModal.tsx
│   │   ├── RegisterModal.tsx
│   │   ├── SellItemModal.tsx
│   │   ├── ChatModal.tsx
│   │   └── Toast.tsx
│   ├── pages/
│   │   ├── Home.tsx       # Main page
│   │   ├── Login.tsx      # Login page (OAuth)
│   │   └── NotFound.tsx
│   ├── hooks/
│   │   └── useAuth.ts     # Dual auth hook
│   ├── providers/
│   │   └── trpc.tsx       # tRPC provider
│   └── index.css          # Global styles + animations
├── docker-compose.yml     # Docker setup
└── .env.example           # Environment template
```

## Environment Variables

See `.env.example` for all required variables. Key ones:

| Variable | Description |
|----------|-------------|
| `DATABASE_URL` | MySQL connection string |
| `APP_ID` / `APP_SECRET` | Kimi OAuth credentials |
| `VITE_APP_ID` | Frontend app ID |
| `VITE_KIMI_AUTH_URL` | Kimi auth URL |

## License

MIT License - feel free to use this for your own marketplace!
