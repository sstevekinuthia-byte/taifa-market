import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { findLocalUserByUsername, findLocalUserById, createLocalUser } from "./queries/localUsers";
import * as jose from "jose";
import { env } from "./lib/env";

const JWT_ALG = "HS256";

async function hashPassword(password: string): Promise<string> {
  // Use Web Crypto API for password hashing
  const encoder = new TextEncoder();
  const data = encoder.encode(password + env.appSecret);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function signLocalToken(userId: number): Promise<string> {
  const secret = new TextEncoder().encode(env.appSecret);
  return new jose.SignJWT({ localUserId: userId })
    .setProtectedHeader({ alg: JWT_ALG })
    .setIssuedAt()
    .setExpirationTime("1 year")
    .sign(secret);
}

export async function verifyLocalToken(
  token: string,
): Promise<{ localUserId: number } | null> {
  if (!token) return null;
  try {
    const secret = new TextEncoder().encode(env.appSecret);
    const { payload } = await jose.jwtVerify(token, secret, {
      algorithms: [JWT_ALG],
      clockTolerance: 60,
    });
    if (!payload.localUserId) return null;
    return { localUserId: payload.localUserId as number };
  } catch {
    return null;
  }
}

export const localAuthRouter = createRouter({
  register: publicQuery
    .input(
      z.object({
        username: z.string().min(3, "Username must be at least 3 characters"),
        password: z.string().min(6, "Password must be at least 6 characters"),
        displayName: z.string().optional(),
        email: z.string().email().optional(),
        phone: z.string().optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const existing = await findLocalUserByUsername(input.username);
      if (existing) {
        throw new Error("Username already taken");
      }

      const passwordHash = await hashPassword(input.password);
      const userId = await createLocalUser({
        username: input.username,
        passwordHash,
        displayName: input.displayName || input.username,
        email: input.email,
        phone: input.phone,
      });

      if (!userId) {
        throw new Error("Failed to create user");
      }

      const token = await signLocalToken(userId);
      const user = await findLocalUserById(userId);

      return {
        token,
        user: {
          id: user!.id,
          username: user!.username,
          name: user!.displayName || user!.username,
          email: user!.email,
          phone: user!.phone,
          role: user!.role,
        },
      };
    }),

  login: publicQuery
    .input(
      z.object({
        username: z.string().min(1),
        password: z.string().min(1),
      }),
    )
    .mutation(async ({ input }) => {
      const user = await findLocalUserByUsername(input.username);
      if (!user) {
        throw new Error("Invalid username or password");
      }

      const passwordHash = await hashPassword(input.password);
      if (user.passwordHash !== passwordHash) {
        throw new Error("Invalid username or password");
      }

      const token = await signLocalToken(user.id);

      return {
        token,
        user: {
          id: user.id,
          username: user.username,
          name: user.displayName || user.username,
          email: user.email,
          phone: user.phone,
          role: user.role,
        },
      };
    }),

  me: publicQuery.query(async ({ ctx }) => {
    const req = ctx.req;
    const cookies = req.headers.get("cookie") || "";
    const localTokenMatch = cookies.match(/local_auth_token=([^;]+)/);
    const localToken = localTokenMatch ? localTokenMatch[1] : null;

    if (!localToken) return null;

    const claim = await verifyLocalToken(localToken);
    if (!claim) return null;

    const user = await findLocalUserById(claim.localUserId);
    if (!user) return null;

    return {
      id: user.id,
      username: user.username,
      name: user.displayName || user.username,
      email: user.email,
      phone: user.phone,
      role: user.role,
    };
  }),
});
